<?php
// user/track.php - Track Garbage Collection Requests & Visual Progress Stepper
require_once __DIR__ . '/includes/bootstrap.php';

$userId = $user['id'];
$selectedId = (int)($_GET['id'] ?? 0);

// Handle Cancel Request Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'cancel') {
    $cancelId = (int)($_POST['request_id'] ?? 0);
    try {
        $stmt = $pdo->prepare("SELECT id, status FROM collection_requests WHERE id = ? AND user_id = ?");
        $stmt->execute([$cancelId, $userId]);
        $req = $stmt->fetch();

        if ($req && $req['status'] === 'Pending') {
            $upd = $pdo->prepare("UPDATE collection_requests SET status = 'Cancelled' WHERE id = ?");
            $upd->execute([$cancelId]);

            // Notification
            $notif = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'status_update')");
            $notif->execute([
                $userId,
                'Request #' . $cancelId . ' Cancelled',
                'You have cancelled your collection request #' . $cancelId . '.'
            ]);

            setFlash('info', 'Collection request #' . $cancelId . ' has been cancelled.');
            header('Location: ' . $baseUrl . '/user/track.php?id=' . $cancelId);
            exit;
        } else {
            setFlash('danger', 'Only requests with "Pending" status can be cancelled.');
        }
    } catch (Exception $e) {
        setFlash('danger', 'Error cancelling request: ' . $e->getMessage());
    }
}

define('PAGE_TITLE', 'Track Garbage Collections | Thika Waste Management');
require_once __DIR__ . '/includes/user_header.php';

// Fetch single request if ID specified
$trackedRequest = null;
if ($selectedId > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT cr.*, wc.name AS category_name, wc.unit AS category_unit, wc.icon AS category_icon
            FROM collection_requests cr
            JOIN waste_categories wc ON cr.category_id = wc.id
            WHERE cr.id = ? AND cr.user_id = ?
        ");
        $stmt->execute([$selectedId, $userId]);
        $trackedRequest = $stmt->fetch();
    } catch (Exception $e) {
        $trackedRequest = null;
    }
}

// Fetch all requests for this user
try {
    $stmt = $pdo->prepare("
        SELECT cr.*, wc.name AS category_name, wc.unit AS category_unit
        FROM collection_requests cr
        JOIN waste_categories wc ON cr.category_id = wc.id
        WHERE cr.user_id = ?
        ORDER BY cr.id DESC
    ");
    $stmt->execute([$userId]);
    $allRequests = $stmt->fetchAll();

    // If no single request is selected but user has requests, default to the latest one
    if (!$trackedRequest && !empty($allRequests) && $selectedId === 0) {
        $trackedRequest = $allRequests[0];
        $selectedId = $trackedRequest['id'];
    }
} catch (Exception $e) {
    die("Error fetching collection history: " . $e->getMessage());
}

// Calculate Stepper State
function getStepperState($status) {
    $steps = [
        1 => ['label' => 'Submitted', 'desc' => 'Order Received'],
        2 => ['label' => 'Approved', 'desc' => 'Truck Scheduled'],
        3 => ['label' => 'In Progress', 'desc' => 'Driver Dispatched'],
        4 => ['label' => 'Completed', 'desc' => 'Waste Disposed']
    ];

    $currentIndex = 1;
    if ($status === 'Approved') $currentIndex = 2;
    elseif ($status === 'In Progress') $currentIndex = 3;
    elseif ($status === 'Completed') $currentIndex = 4;
    elseif ($status === 'Cancelled') $currentIndex = 0;

    return ['steps' => $steps, 'currentIndex' => $currentIndex];
}
?>

<main class="main-content">
    <div class="container">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
            <div>
                <h2><i class="fa fa-route" style="color:var(--primary); margin-right:8px;"></i> Live Collection Tracking</h2>
                <p style="margin:0;">Monitor the progress of your waste collection crews in real time.</p>
            </div>
            <a href="<?= $baseUrl ?>/user/request_collection.php" class="btn btn-primary">
                <i class="fa fa-plus-circle"></i> New Pickup Request
            </a>
        </div>

        <?php if ($trackedRequest): ?>
            <?php 
                $stepper = getStepperState($trackedRequest['status']);
                $currIdx = $stepper['currentIndex'];
            ?>
            <div class="card" style="padding:2rem; margin-bottom:2rem; border-top:4px solid var(--primary);">
                <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:1rem; margin-bottom:1.5rem;">
                    <div>
                        <div style="font-size:0.85rem; color:var(--slate-400); text-transform:uppercase; font-weight:700;">
                            Tracking Request
                        </div>
                        <h3 style="font-size:1.75rem; margin:0.25rem 0;">
                            #<?= $trackedRequest['id'] ?> &mdash; <?= htmlspecialchars($trackedRequest['category_name']) ?>
                        </h3>
                        <div style="font-size:0.9rem; color:var(--slate-600);">
                            <i class="fa fa-map-marker-alt" style="color:var(--primary);"></i> <?= htmlspecialchars($trackedRequest['estate_zone']) ?> &bull; <?= htmlspecialchars($trackedRequest['pickup_address']) ?>
                        </div>
                    </div>

                    <div style="text-align:right;">
                        <div style="margin-bottom:0.4rem;">
                            <?= statusBadge($trackedRequest['status']) ?>
                            <?= statusBadge($trackedRequest['payment_status']) ?>
                        </div>
                        <div style="font-size:1.5rem; font-weight:800; color:var(--primary);">
                            <?= formatKES($trackedRequest['total_amount']) ?>
                        </div>
                    </div>
                </div>

                <!-- Visual Progress Stepper -->
                <?php if ($trackedRequest['status'] === 'Cancelled'): ?>
                    <div class="alert alert-danger" style="margin:1.5rem 0;">
                        <i class="fa fa-times-circle" style="font-size:1.25rem;"></i>
                        <div>
                            <strong>This request has been cancelled.</strong>
                            <div>If you still require waste clearing, please schedule a new request.</div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="tracker-stepper">
                        <?php foreach ($stepper['steps'] as $idx => $step): ?>
                            <?php 
                                $isCompleted = ($idx <= $currIdx);
                                $isActive = ($idx === $currIdx);
                                $stepClass = $isCompleted ? 'completed' : ($isActive ? 'active' : '');
                            ?>
                            <div class="tracker-step <?= $stepClass ?>">
                                <div class="tracker-step-circle">
                                    <?php if ($idx < $currIdx): ?>
                                        <i class="fa fa-check"></i>
                                    <?php else: ?>
                                        <?= $idx ?>
                                    <?php endif; ?>
                                </div>
                                <div class="tracker-step-title"><?= htmlspecialchars($step['label']) ?></div>
                                <div style="font-size:0.75rem; color:var(--slate-400);"><?= htmlspecialchars($step['desc']) ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- Detailed Information Grid -->
                <div style="background:var(--slate-50); border:1px solid var(--slate-200); border-radius:var(--radius-md); padding:1.5rem; margin-top:2rem;">
                    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:1.25rem;">
                        <div>
                            <span style="font-size:0.8rem; color:var(--slate-400); display:block;">Pickup Date</span>
                            <strong><?= date('l, d M Y', strtotime($trackedRequest['pickup_date'])) ?></strong>
                        </div>
                        <div>
                            <span style="font-size:0.8rem; color:var(--slate-400); display:block;">Time Window</span>
                            <strong><?= htmlspecialchars($trackedRequest['pickup_time_slot']) ?></strong>
                        </div>
                        <div>
                            <span style="font-size:0.8rem; color:var(--slate-400); display:block;">Quantity</span>
                            <strong><?= $trackedRequest['quantity'] ?> Units (<?= formatKES($trackedRequest['unit_price']) ?> / unit)</strong>
                        </div>
                        <div>
                            <span style="font-size:0.8rem; color:var(--slate-400); display:block;">Created At</span>
                            <strong><?= date('d M Y, H:i', strtotime($trackedRequest['created_at'])) ?></strong>
                        </div>
                    </div>

                    <?php if (!empty($trackedRequest['notes'])): ?>
                        <hr style="border:0; border-top:1px solid var(--slate-200); margin:1rem 0;">
                        <div>
                            <span style="font-size:0.8rem; color:var(--slate-400); display:block; margin-bottom:0.25rem;">Pickup Notes / Handling Details:</span>
                            <div style="font-size:0.9rem; color:var(--slate-600); white-space:pre-line;"><?= htmlspecialchars($trackedRequest['notes']) ?></div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Action Buttons -->
                <div style="display:flex; justify-content:flex-end; gap:0.75rem; margin-top:1.5rem; flex-wrap:wrap;">
                    <?php if ($trackedRequest['payment_status'] === 'Unpaid'): ?>
                        <a href="<?= $baseUrl ?>/user/payments.php?request_id=<?= $trackedRequest['id'] ?>" class="btn btn-success">
                            <i class="fa fa-credit-card"></i> Pay <?= formatKES($trackedRequest['total_amount']) ?> via M-Pesa
                        </a>
                    <?php endif; ?>

                    <a href="<?= $baseUrl ?>/user/messages.php?ref=<?= $trackedRequest['id'] ?>" class="btn btn-secondary">
                        <i class="fa fa-comment-alt"></i> Ask Dispatch About This
                    </a>

                    <?php if ($trackedRequest['status'] === 'Pending'): ?>
                        <form action="<?= $baseUrl ?>/user/track.php" method="POST" onsubmit="return confirm('Are you sure you want to cancel request #<?= $trackedRequest['id'] ?>?');" style="display:inline;">
                            <input type="hidden" name="action" value="cancel">
                            <input type="hidden" name="request_id" value="<?= $trackedRequest['id'] ?>">
                            <button type="submit" class="btn btn-danger">
                                <i class="fa fa-times"></i> Cancel Request
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- All Requests Table -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fa fa-history" style="color:var(--primary); margin-right:8px;"></i> My Full Collection History</h3>
            </div>

            <?php if (empty($allRequests)): ?>
                <div style="text-align:center; padding:3rem 1rem;">
                    <i class="fa fa-box-open" style="font-size:2.5rem; color:var(--slate-300); margin-bottom:1rem;"></i>
                    <h4>No Collection History</h4>
                    <p style="color:var(--slate-400);">You have not scheduled any garbage pickups yet.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Thika Zone</th>
                                <th>Scheduled Date</th>
                                <th>Amount</th>
                                <th>Payment</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($allRequests as $req): ?>
                                <tr style="<?= ($selectedId === (int)$req['id']) ? 'background:#ecfdf5;' : '' ?>">
                                    <td><strong>#<?= $req['id'] ?></strong></td>
                                    <td><?= htmlspecialchars($req['category_name']) ?></td>
                                    <td><?= $req['quantity'] ?></td>
                                    <td><?= htmlspecialchars($req['estate_zone']) ?></td>
                                    <td><?= date('d M Y', strtotime($req['pickup_date'])) ?></td>
                                    <td><strong><?= formatKES($req['total_amount']) ?></strong></td>
                                    <td><?= statusBadge($req['payment_status']) ?></td>
                                    <td><?= statusBadge($req['status']) ?></td>
                                    <td>
                                        <a href="<?= $baseUrl ?>/user/track.php?id=<?= $req['id'] ?>" class="btn btn-sm <?= ($selectedId === (int)$req['id']) ? 'btn-primary' : 'btn-secondary' ?>">
                                            <i class="fa fa-search"></i> View
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/includes/user_footer.php'; ?>
