<?php
// user/payments.php - Resident Payment Management & M-Pesa Checkout Simulator
require_once __DIR__ . '/includes/bootstrap.php';

$userId = $user['id'];
$targetRequestId = (int)($_GET['request_id'] ?? 0);

// Handle Payment Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_request_id'])) {
    $payReqId = (int)$_POST['pay_request_id'];
    $method = trim($_POST['payment_method'] ?? 'M-Pesa');
    $txRef = trim($_POST['transaction_reference'] ?? '');

    if (empty($txRef)) {
        $txRef = 'QK' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
    }

    try {
        // Verify request belongs to user and get total
        $stmt = $pdo->prepare("SELECT id, total_amount, payment_status, estate_zone FROM collection_requests WHERE id = ? AND user_id = ?");
        $stmt->execute([$payReqId, $userId]);
        $req = $stmt->fetch();

        if ($req) {
            $amount = (float)$req['total_amount'];

            // Insert payment
            $ins = $pdo->prepare("INSERT INTO payments (request_id, user_id, amount, payment_method, transaction_reference, payment_status) VALUES (?, ?, ?, ?, ?, 'Completed')");
            $ins->execute([$payReqId, $userId, $amount, $method, $txRef]);

            // Update collection request payment status
            $upd = $pdo->prepare("UPDATE collection_requests SET payment_status = 'Paid' WHERE id = ?");
            $upd->execute([$payReqId]);

            // Notification
            $notif = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'payment')");
            $notif->execute([
                $userId,
                'Payment Received - KES ' . number_format($amount, 2),
                'Thank you! Your payment of ' . formatKES($amount) . ' for Request #' . $payReqId . ' via ' . $method . ' was confirmed (Ref: ' . $txRef . ').'
            ]);

            setFlash('success', 'Payment of ' . formatKES($amount) . ' confirmed successfully! Reference: ' . $txRef);
            header('Location: ' . $baseUrl . '/user/payments.php');
            exit;
        } else {
            setFlash('danger', 'Collection request not found or does not belong to your account.');
        }
    } catch (Exception $e) {
        setFlash('danger', 'Payment failed: ' . $e->getMessage());
    }
}

define('PAGE_TITLE', 'Payments & Invoices | Thika Waste Management');
require_once __DIR__ . '/includes/user_header.php';

// Fetch unpaid requests for this user
try {
    $stmt = $pdo->prepare("
        SELECT cr.*, wc.name AS category_name, wc.unit AS category_unit 
        FROM collection_requests cr
        JOIN waste_categories wc ON cr.category_id = wc.id
        WHERE cr.user_id = ? AND cr.payment_status != 'Paid' AND cr.status != 'Cancelled'
        ORDER BY cr.id DESC
    ");
    $stmt->execute([$userId]);
    $unpaidRequests = $stmt->fetchAll();

    // Fetch payment history
    $stmt = $pdo->prepare("
        SELECT p.*, cr.estate_zone, wc.name AS category_name
        FROM payments p
        JOIN collection_requests cr ON p.request_id = cr.id
        JOIN waste_categories wc ON cr.category_id = wc.id
        WHERE p.user_id = ?
        ORDER BY p.id DESC
    ");
    $stmt->execute([$userId]);
    $paymentHistory = $stmt->fetchAll();

} catch (Exception $e) {
    die("Error fetching payment records: " . $e->getMessage());
}

// Target unpaid request for checkout
$activeBill = null;
if ($targetRequestId > 0) {
    foreach ($unpaidRequests as $ub) {
        if ((int)$ub['id'] === $targetRequestId) {
            $activeBill = $ub;
            break;
        }
    }
}
if (!$activeBill && !empty($unpaidRequests)) {
    $activeBill = $unpaidRequests[0];
}
?>

<main class="main-content">
    <div class="container">
        <div style="margin-bottom:1.5rem;">
            <h2><i class="fa fa-credit-card" style="color:var(--primary); margin-right:8px;"></i> Payments & Billing</h2>
            <p style="margin:0;">Pay for your scheduled garbage collection orders via M-Pesa and view official digital receipts.</p>
        </div>

        <div style="display:grid; grid-template-columns: 1.2fr 1.8fr; gap:2rem; margin-bottom:2.5rem;">
            <!-- M-Pesa Checkout Panel -->
            <div class="card" style="border-top:4px solid #10b981; padding:2rem;">
                <div style="display:flex; align-items:center; gap:0.75rem; margin-bottom:1.25rem;">
                    <div style="background:#059669; color:#fff; width:44px; height:44px; border-radius:var(--radius-md); display:flex; align-items:center; justify-content:center; font-size:1.4rem;">
                        <i class="fa fa-mobile-alt"></i>
                    </div>
                    <div>
                        <h3 style="margin:0; font-size:1.2rem;">M-Pesa Express Checkout</h3>
                        <small style="color:var(--slate-400);">Instant STK Push / Paybill Simulator</small>
                    </div>
                </div>

                <?php if ($activeBill): ?>
                    <div style="background:var(--slate-100); border-radius:var(--radius-md); padding:1rem; margin-bottom:1.5rem;">
                        <div style="display:flex; justify-content:space-between; margin-bottom:0.4rem; font-size:0.875rem;">
                            <span style="color:var(--slate-600);">Request Reference:</span>
                            <strong>#<?= $activeBill['id'] ?> (<?= htmlspecialchars($activeBill['category_name']) ?>)</strong>
                        </div>
                        <div style="display:flex; justify-content:space-between; margin-bottom:0.4rem; font-size:0.875rem;">
                            <span style="color:var(--slate-600);">Estate:</span>
                            <span><?= htmlspecialchars($activeBill['estate_zone']) ?></span>
                        </div>
                        <div style="display:flex; justify-content:space-between; align-items:baseline; margin-top:0.5rem; border-top:1px solid var(--slate-200); padding-top:0.5rem;">
                            <span style="font-weight:700;">Amount Due:</span>
                            <strong style="font-size:1.4rem; color:var(--primary);"><?= formatKES($activeBill['total_amount']) ?></strong>
                        </div>
                    </div>

                    <form action="<?= $baseUrl ?>/user/payments.php" method="POST" id="payment_form">
                        <input type="hidden" name="pay_request_id" value="<?= $activeBill['id'] ?>">
                        <input type="hidden" name="payment_method" value="M-Pesa">

                        <div class="form-group">
                            <label class="form-label">M-Pesa Phone Number</label>
                            <input type="tel" id="mpesa_phone" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>" placeholder="07XXXXXXXX" required>
                            <small class="form-help">Enter Safaricom number to receive the prompt.</small>
                        </div>

                        <!-- STK Simulation Display Box -->
                        <div id="stk_status_box" style="display:none; margin-bottom:1.25rem;"></div>

                        <div class="form-group">
                            <label class="form-label">M-Pesa Confirmation Code (Or Click Below to Simulate)</label>
                            <input type="text" name="transaction_reference" id="transaction_reference" class="form-control" placeholder="e.g. QK8912LX01" style="text-transform:uppercase;">
                        </div>

                        <div style="display:flex; flex-direction:column; gap:0.75rem;">
                            <button type="button" id="btn_simulate_stk" class="btn btn-success btn-block btn-lg" style="background:#059669;">
                                <i class="fa fa-bolt"></i> Send STK Push to Phone
                            </button>

                            <button type="submit" id="btn_complete_payment" class="btn btn-primary btn-block">
                                <i class="fa fa-check-circle"></i> Submit Payment Code
                            </button>
                        </div>
                    </form>

                    <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:var(--radius-md); padding:0.75rem; margin-top:1.25rem; font-size:0.8rem; color:#166534;">
                        <strong>Manual Paybill Instructions:</strong><br>
                        Business No: <strong>247247</strong> &bull; Account: <strong>THIKA-<?= $activeBill['id'] ?></strong>
                    </div>

                <?php else: ?>
                    <div style="text-align:center; padding:2rem 1rem;">
                        <i class="fa fa-check-double" style="font-size:2.5rem; color:var(--success); margin-bottom:0.75rem;"></i>
                        <h4>All Bills Are Cleared!</h4>
                        <p style="color:var(--slate-400); font-size:0.9rem;">You have zero pending unpaid garbage collection requests.</p>
                        <a href="<?= $baseUrl ?>/user/request_collection.php" class="btn btn-sm btn-primary">
                            <i class="fa fa-plus-circle"></i> Book New Collection
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Unpaid Requests List -->
            <div class="card" style="padding:2rem;">
                <div class="card-header" style="padding-top:0;">
                    <h3><i class="fa fa-exclamation-circle" style="color:var(--warning); margin-right:8px;"></i> Pending Invoices</h3>
                </div>

                <?php if (empty($unpaidRequests)): ?>
                    <p style="color:var(--slate-400); text-align:center; padding:2rem 0;">No outstanding bills found.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Req #</th>
                                    <th>Category</th>
                                    <th>Date</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($unpaidRequests as $unp): ?>
                                    <tr style="<?= ($activeBill && $activeBill['id'] == $unp['id']) ? 'background:#ecfdf5;' : '' ?>">
                                        <td><strong>#<?= $unp['id'] ?></strong></td>
                                        <td><?= htmlspecialchars($unp['category_name']) ?></td>
                                        <td><?= date('d M Y', strtotime($unp['pickup_date'])) ?></td>
                                        <td><strong><?= formatKES($unp['total_amount']) ?></strong></td>
                                        <td>
                                            <a href="<?= $baseUrl ?>/user/payments.php?request_id=<?= $unp['id'] ?>" class="btn btn-sm btn-primary">
                                                Select & Pay
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Payment History Table -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fa fa-receipt" style="color:var(--primary); margin-right:8px;"></i> Official Payment History & Receipts</h3>
            </div>

            <?php if (empty($paymentHistory)): ?>
                <div style="text-align:center; padding:2.5rem 0;">
                    <i class="fa fa-file-invoice" style="font-size:2.5rem; color:var(--slate-300); margin-bottom:0.75rem;"></i>
                    <p style="color:var(--slate-400);">No payment records found.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Receipt #</th>
                                <th>Order Ref</th>
                                <th>Waste Category</th>
                                <th>Payment Method</th>
                                <th>M-Pesa Reference</th>
                                <th>Amount Paid</th>
                                <th>Payment Date</th>
                                <th>Status</th>
                                <th>Receipt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($paymentHistory as $pay): ?>
                                <tr>
                                    <td><strong>REC-<?= str_pad($pay['id'], 5, '0', STR_PAD_LEFT) ?></strong></td>
                                    <td><a href="<?= $baseUrl ?>/user/track.php?id=<?= $pay['request_id'] ?>">#<?= $pay['request_id'] ?></a></td>
                                    <td><?= htmlspecialchars($pay['category_name']) ?></td>
                                    <td><i class="fa fa-mobile-alt" style="color:#059669;"></i> <?= htmlspecialchars($pay['payment_method']) ?></td>
                                    <td><code><?= htmlspecialchars($pay['transaction_reference']) ?></code></td>
                                    <td><strong><?= formatKES($pay['amount']) ?></strong></td>
                                    <td><?= date('d M Y, H:i', strtotime($pay['paid_at'])) ?></td>
                                    <td><?= statusBadge($pay['payment_status']) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-secondary" onclick="printReceipt('REC-<?= str_pad($pay['id'], 5, '0', STR_PAD_LEFT) ?>', '<?= htmlspecialchars($pay['category_name']) ?>', '<?= formatKES($pay['amount']) ?>', '<?= htmlspecialchars($pay['transaction_reference']) ?>', '<?= date('d M Y, H:i', strtotime($pay['paid_at'])) ?>')">
                                            <i class="fa fa-print"></i> Print
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<!-- Printable Receipt Modal -->
<div class="modal-overlay" id="receiptModal">
    <div class="modal-box" style="max-width:450px;">
        <div class="modal-header">
            <h4 style="margin:0;"><i class="fa fa-receipt" style="color:var(--primary);"></i> Municipal Waste Receipt</h4>
            <button class="alert-close" onclick="closeModal('receiptModal')">&times;</button>
        </div>
        <div class="modal-body" id="printableReceiptArea" style="text-align:center;">
            <div style="font-size:1.4rem; font-weight:800; color:var(--dark);">ThikaClean Waste</div>
            <div style="font-size:0.8rem; color:var(--slate-400); margin-bottom:1rem;">Kiambu County Municipal Certified</div>
            <hr style="border:0; border-top:1px dashed var(--slate-300); margin:1rem 0;">

            <div style="text-align:left; font-size:0.875rem; line-height:1.8;">
                <div style="display:flex; justify-content:space-between;">
                    <span style="color:var(--slate-600);">Receipt No:</span>
                    <strong id="rcpt_no">-</strong>
                </div>
                <div style="display:flex; justify-content:space-between;">
                    <span style="color:var(--slate-600);">Resident Name:</span>
                    <strong><?= htmlspecialchars($user['name']) ?></strong>
                </div>
                <div style="display:flex; justify-content:space-between;">
                    <span style="color:var(--slate-600);">Estate Zone:</span>
                    <strong><?= htmlspecialchars($user['estate']) ?></strong>
                </div>
                <div style="display:flex; justify-content:space-between;">
                    <span style="color:var(--slate-600);">Waste Item:</span>
                    <strong id="rcpt_category">-</strong>
                </div>
                <div style="display:flex; justify-content:space-between;">
                    <span style="color:var(--slate-600);">M-Pesa Reference:</span>
                    <code id="rcpt_ref" style="font-weight:700;">-</code>
                </div>
                <div style="display:flex; justify-content:space-between;">
                    <span style="color:var(--slate-600);">Date & Time:</span>
                    <span id="rcpt_date">-</span>
                </div>
                <hr style="border:0; border-top:1px dashed var(--slate-300); margin:0.75rem 0;">
                <div style="display:flex; justify-content:space-between; font-size:1.1rem;">
                    <strong>Amount Paid:</strong>
                    <strong id="rcpt_amount" style="color:var(--primary);">-</strong>
                </div>
            </div>

            <div style="margin-top:1.5rem; font-size:0.75rem; color:var(--slate-400);">
                Thank you for contributing to a cleaner Thika environment!<br>
                For questions, call +254 712 345 678.
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('receiptModal')">Close</button>
            <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> Print Receipt</button>
        </div>
    </div>
</div>

<script>
function printReceipt(recNo, category, amount, ref, date) {
    document.getElementById('rcpt_no').textContent = recNo;
    document.getElementById('rcpt_category').textContent = category;
    document.getElementById('rcpt_amount').textContent = amount;
    document.getElementById('rcpt_ref').textContent = ref;
    document.getElementById('rcpt_date').textContent = date;
    openModal('receiptModal');
}
</script>

<?php require_once __DIR__ . '/includes/user_footer.php'; ?>
