<?php
// user/notifications.php - Resident Notifications & Reminders Center
require_once __DIR__ . '/includes/bootstrap.php';

$userId = $user['id'];

// Handle Mark All As Read
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mark_all_read') {
    try {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE (user_id = ? OR user_id IS NULL)");
        $stmt->execute([$userId]);
        setFlash('success', 'All notifications marked as read.');
        header('Location: ' . $baseUrl . '/user/notifications.php');
        exit;
    } catch (Exception $e) {}
}

define('PAGE_TITLE', 'Notifications & Reminders | Thika Waste Management');
require_once __DIR__ . '/includes/user_header.php';

// Fetch all notifications for this user (or global)
try {
    $stmt = $pdo->prepare("
        SELECT * FROM notifications 
        WHERE (user_id = ? OR user_id IS NULL)
        ORDER BY id DESC
    ");
    $stmt->execute([$userId]);
    $notifications = $stmt->fetchAll();
} catch (Exception $e) {
    die("Error loading notifications: " . $e->getMessage());
}
?>

<main class="main-content">
    <div class="container" style="max-width:850px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
            <div>
                <h2><i class="fa fa-bell" style="color:var(--accent); margin-right:8px;"></i> My Notifications & Reminders</h2>
                <p style="margin:0;">Stay updated on garbage truck arrivals, payment confirmations, and municipal announcements.</p>
            </div>

            <?php if (!empty($notifications)): ?>
                <form action="<?= $baseUrl ?>/user/notifications.php" method="POST">
                    <input type="hidden" name="action" value="mark_all_read">
                    <button type="submit" class="btn btn-sm btn-secondary">
                        <i class="fa fa-check-double"></i> Mark All as Read
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <div class="card" style="padding:1.5rem;">
            <?php if (empty($notifications)): ?>
                <div style="text-align:center; padding:3rem 1rem;">
                    <i class="fa fa-bell-slash" style="font-size:3rem; color:var(--slate-300); margin-bottom:1rem;"></i>
                    <h4>No Notifications</h4>
                    <p style="color:var(--slate-400); font-size:0.9rem;">You are all caught up! When our team dispatches trucks or updates your pickups, notices will appear here.</p>
                </div>
            <?php else: ?>
                <div style="display:flex; flex-direction:column; gap:1rem;">
                    <?php foreach ($notifications as $n): ?>
                        <?php 
                            $typeColor = 'var(--info)';
                            $typeIcon = 'fa-info-circle';
                            $typeBadgeClass = 'badge-info';

                            if ($n['type'] === 'reminder') {
                                $typeColor = 'var(--accent)';
                                $typeIcon = 'fa-clock';
                                $typeBadgeClass = 'badge-warning';
                            } elseif ($n['type'] === 'payment') {
                                $typeColor = 'var(--primary)';
                                $typeIcon = 'fa-check-circle';
                                $typeBadgeClass = 'badge-success';
                            } elseif ($n['type'] === 'status_update') {
                                $typeColor = '#0ea5e9';
                                $typeIcon = 'fa-truck';
                                $typeBadgeClass = 'badge-primary';
                            }
                        ?>
                        <div style="background: <?= $n['is_read'] ? '#ffffff' : '#f8fafc' ?>; border:1px solid var(--slate-200); border-left: 4px solid <?= $typeColor ?>; border-radius:var(--radius-md); padding:1.25rem; display:flex; justify-content:space-between; align-items:flex-start; gap:1rem;">
                            <div style="flex:1;">
                                <div style="display:flex; align-items:center; gap:0.5rem; margin-bottom:0.4rem;">
                                    <span class="badge <?= $typeBadgeClass ?>">
                                        <i class="fa <?= $typeIcon ?>"></i> <?= ucfirst($n['type']) ?>
                                    </span>
                                    <?php if (!$n['is_read']): ?>
                                        <span class="badge badge-danger">Unread</span>
                                    <?php endif; ?>
                                    <span style="font-size:0.75rem; color:var(--slate-400);">
                                        <i class="fa fa-calendar-alt"></i> <?= date('d M Y, H:i', strtotime($n['created_at'])) ?>
                                    </span>
                                </div>
                                <h4 style="margin:0 0 0.4rem 0; font-size:1.05rem;"><?= htmlspecialchars($n['title']) ?></h4>
                                <p style="margin:0; font-size:0.9rem; color:var(--slate-600);"><?= htmlspecialchars($n['message']) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/includes/user_footer.php'; ?>
