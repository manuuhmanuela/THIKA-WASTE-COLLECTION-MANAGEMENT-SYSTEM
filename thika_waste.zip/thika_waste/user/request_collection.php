<?php
// user/request_collection.php - Schedule Garbage Collection
require_once __DIR__ . '/includes/bootstrap.php';

$errors = [];
$preselectedCategory = (int)($_GET['category_id'] ?? 0);
$preselectedZone = $_GET['estate_zone'] ?? $user['estate'];

// Fetch categories from DB
try {
    $stmt = $pdo->query("SELECT * FROM waste_categories WHERE status = 'active' ORDER BY id ASC");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {
    die("Error fetching categories: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $quantity = (int)($_POST['quantity'] ?? 1);
    $estateZone = trim($_POST['estate_zone'] ?? '');
    $pickupAddress = trim($_POST['pickup_address'] ?? '');
    $pickupDate = trim($_POST['pickup_date'] ?? '');
    $pickupTimeSlot = trim($_POST['pickup_time_slot'] ?? '');
    $containerType = trim($_POST['container_type'] ?? 'Standard Plastic Sacks');
    $frequency = trim($_POST['frequency'] ?? 'One-Off On-Demand Pickup');
    $weightEstimate = trim($_POST['weight_estimate'] ?? '20kg - 50kg');
    $paymentMethod = trim($_POST['payment_method'] ?? 'M-Pesa');
    $specialNotes = trim($_POST['notes'] ?? '');

    // Validation
    if ($categoryId <= 0) $errors[] = 'Please select a valid garbage category.';
    if ($quantity <= 0) $errors[] = 'Quantity must be at least 1.';
    if (empty($estateZone)) $errors[] = 'Please select your Thika estate / zone.';
    if (empty($pickupAddress)) $errors[] = 'Specific pickup address / landmark is required.';
    if (empty($pickupDate)) $errors[] = 'Please specify a preferred pickup date.';
    if (empty($pickupTimeSlot)) $errors[] = 'Please select a preferred pickup time window.';

    if (empty($errors)) {
        // Find category price
        $selectedCat = null;
        foreach ($categories as $cat) {
            if ((int)$cat['id'] === $categoryId) {
                $selectedCat = $cat;
                break;
            }
        }

        if (!$selectedCat) {
            $errors[] = 'Selected garbage category was not found.';
        } else {
            $unitPrice = (float)$selectedCat['base_price'];
            $totalAmount = $unitPrice * $quantity;

            // Combine detailed metadata into notes
            $fullNotes = "Container: " . $containerType . "\n"
                       . "Frequency: " . $frequency . "\n"
                       . "Est. Weight: " . $weightEstimate . "\n"
                       . "Preferred Payment: " . $paymentMethod . "\n"
                       . ($specialNotes ? "Instructions: " . $specialNotes : "");

            try {
                $stmt = $pdo->prepare("
                    INSERT INTO collection_requests 
                    (user_id, category_id, quantity, unit_price, total_amount, pickup_date, pickup_time_slot, pickup_address, estate_zone, notes, status, payment_status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', 'Unpaid')
                ");
                $stmt->execute([
                    $user['id'],
                    $categoryId,
                    $quantity,
                    $unitPrice,
                    $totalAmount,
                    $pickupDate,
                    $pickupTimeSlot,
                    $pickupAddress,
                    $estateZone,
                    $fullNotes
                ]);
                $newRequestId = $pdo->lastInsertId();

                // Generate confirmation notification
                $notifStmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'status_update')");
                $notifStmt->execute([
                    $user['id'],
                    'Pickup Request #' . $newRequestId . ' Submitted',
                    'Your collection order for ' . htmlspecialchars($selectedCat['name']) . ' in ' . htmlspecialchars($estateZone) . ' is Pending confirmation. Total: ' . formatKES($totalAmount),
                ]);

                setFlash('success', 'Your garbage collection request #' . $newRequestId . ' has been booked successfully! You can track progress below.');
                
                // If payment method is M-Pesa, redirect to checkout prompt, else tracking
                if ($paymentMethod === 'M-Pesa') {
                    header('Location: ' . $baseUrl . '/user/payments.php?request_id=' . $newRequestId . '&auto_pay=1');
                } else {
                    header('Location: ' . $baseUrl . '/user/track.php?id=' . $newRequestId);
                }
                exit;

            } catch (Exception $e) {
                $errors[] = 'Failed to submit request: ' . $e->getMessage();
            }
        }
    }
}

define('PAGE_TITLE', 'Collect Garbage | Schedule Waste Pickup in Thika');
require_once __DIR__ . '/includes/user_header.php';
?>

<main class="main-content">
    <div class="container">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
            <div>
                <h2><i class="fa fa-truck-pickup" style="color:var(--primary); margin-right:8px;"></i> Schedule Garbage Collection</h2>
                <p style="margin:0;">Fill in the details below to dispatch a municipal waste collection crew to your Thika location.</p>
            </div>
            <a href="<?= $baseUrl ?>/user/track.php" class="btn btn-outline-primary">
                <i class="fa fa-route"></i> Track Existing Pickups
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul style="margin:0; padding-left:1.25rem;">
                    <?php foreach ($errors as $err): ?>
                        <li><?= htmlspecialchars($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?= $baseUrl ?>/user/request_collection.php" method="POST">
            <div style="display:grid; grid-template-columns: 2fr 1fr; gap:2rem;">
                <!-- Main Form Column -->
                <div class="card" style="padding:2rem;">
                    <h3 style="border-bottom:1px solid var(--slate-100); padding-bottom:0.75rem; margin-bottom:1.25rem;">
                        1. Waste Type & Quantity Details
                    </h3>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Type / Category of Garbage <span style="color:var(--danger);">*</span></label>
                            <select name="category_id" id="category_id" class="form-control" required>
                                <option value="">-- Select Garbage Type --</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>" 
                                            data-price="<?= $cat['base_price'] ?>" 
                                            data-unit="<?= htmlspecialchars($cat['unit']) ?>"
                                            data-desc="<?= htmlspecialchars($cat['description']) ?>"
                                            <?= ($preselectedCategory === (int)$cat['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat['name']) ?> (<?= formatKES($cat['base_price']) ?> / <?= htmlspecialchars($cat['unit']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <small id="display_category_desc" class="form-help" style="color:var(--primary);">
                                Choose what kind of waste you want collected.
                            </small>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Quantity / Number of Units <span style="color:var(--danger);">*</span></label>
                            <input type="number" name="quantity" id="quantity" class="form-control" min="1" max="100" value="<?= htmlspecialchars($_POST['quantity'] ?? '1') ?>" required>
                            <small class="form-help">Number of bags, wheelie bins, or truck loads to clear.</small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Container / Packaging Type</label>
                            <select name="container_type" class="form-control">
                                <option value="Standard Heavy-duty Sacks / Bags">Standard Heavy-duty Sacks / Bags</option>
                                <option value="240L Municipal Wheelie Bin">240L Municipal Wheelie Bin</option>
                                <option value="Cardboard Cartons / Boxes">Cardboard Cartons / Boxes</option>
                                <option value="Domestic Plastic Drums">Domestic Plastic Drums</option>
                                <option value="Loose Heap / Bulk Yard Pile">Loose Heap / Bulk Yard Pile</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Approximate Weight / Volume</label>
                            <select name="weight_estimate" class="form-control">
                                <option value="Light (Under 20kg)">Light (Under 20kg)</option>
                                <option value="Moderate (20kg - 50kg)" selected>Moderate (20kg - 50kg)</option>
                                <option value="Heavy (50kg - 100kg)">Heavy (50kg - 100kg)</option>
                                <option value="Bulk Load (Above 100kg)">Bulk Load (Above 100kg)</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Collection Frequency</label>
                        <select name="frequency" class="form-control">
                            <option value="One-Off On-Demand Pickup" selected>One-Off On-Demand Pickup</option>
                            <option value="Weekly Recurring Collection">Weekly Recurring Collection</option>
                            <option value="Bi-Weekly (Twice a Week) Commercial">Bi-Weekly (Twice a Week) Commercial</option>
                            <option value="Monthly Routine Service">Monthly Routine Service</option>
                        </select>
                    </div>

                    <h3 style="border-bottom:1px solid var(--slate-100); padding-bottom:0.75rem; margin:1.75rem 0 1.25rem;">
                        2. Thika Location & Schedule
                    </h3>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Thika Estate / Zone <span style="color:var(--danger);">*</span></label>
                            <select name="estate_zone" class="form-control" required>
                                <option value="">-- Select Estate in Thika --</option>
                                <?php foreach (getThikaZones() as $zone): ?>
                                    <option value="<?= htmlspecialchars($zone) ?>" <?= ($preselectedZone === $zone) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($zone) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Pickup Date <span style="color:var(--danger);">*</span></label>
                            <input type="date" name="pickup_date" class="form-control" min="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($_POST['pickup_date'] ?? date('Y-m-d', strtotime('+1 day'))) ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Preferred Time Window <span style="color:var(--danger);">*</span></label>
                            <select name="pickup_time_slot" class="form-control" required>
                                <option value="Morning (8:00 AM - 11:00 AM)">Morning (8:00 AM - 11:00 AM)</option>
                                <option value="Midday (11:00 AM - 2:00 PM)">Midday (11:00 AM - 2:00 PM)</option>
                                <option value="Afternoon (2:00 PM - 5:00 PM)">Afternoon (2:00 PM - 5:00 PM)</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Payment Preference <span style="color:var(--danger);">*</span></label>
                            <select name="payment_method" class="form-control" required>
                                <option value="M-Pesa" selected>M-Pesa (Instant STK Push / Till)</option>
                                <option value="Cash on Collection">Cash on Collection (Pay Loader Driver)</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Specific Pickup Address & Landmarks <span style="color:var(--danger);">*</span></label>
                        <input type="text" name="pickup_address" class="form-control" placeholder="e.g. Makongeni Phase 4, Green Gate near St. Mulumba Hospital" value="<?= htmlspecialchars($_POST['pickup_address'] ?? '') ?>" required>
                        <small class="form-help">Include gate colour, house number, or nearest shop/school.</small>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Special Instructions / Compound Access Details</label>
                        <textarea name="notes" class="form-control" placeholder="e.g. Bins are placed beside the car port; gate passcode is #1234; watch out for dog in compound..."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                    </div>
                </div>

                <!-- Live Price Calculation Sidebar -->
                <div>
                    <div class="card" style="position:sticky; top:85px; border-top:4px solid var(--primary);">
                        <h3 style="margin-bottom:1rem; font-size:1.25rem;">
                            <i class="fa fa-receipt" style="color:var(--primary); margin-right:8px;"></i> Cost Estimate
                        </h3>

                        <div style="background:var(--slate-50); border:1px solid var(--slate-200); border-radius:var(--radius-md); padding:1.25rem; margin-bottom:1.5rem;">
                            <div style="display:flex; justify-content:space-between; margin-bottom:0.75rem; font-size:0.9rem; color:var(--slate-600);">
                                <span>Unit Rate:</span>
                                <strong id="display_unit_price" style="color:var(--dark);">KES 0.00</strong>
                            </div>
                            <div style="display:flex; justify-content:space-between; margin-bottom:0.75rem; font-size:0.9rem; color:var(--slate-600);">
                                <span>Unit Basis:</span>
                                <span id="display_unit_name" style="color:var(--slate-600); font-weight:600;">-</span>
                            </div>
                            <hr style="border:0; border-top:1px solid var(--slate-200); margin:0.75rem 0;">
                            <div style="display:flex; justify-content:space-between; align-items:baseline;">
                                <span style="font-weight:700; color:var(--dark);">Total Amount:</span>
                                <strong id="display_total_amount" style="font-size:1.5rem; color:var(--primary);">KES 0.00</strong>
                            </div>
                            <input type="hidden" id="total_amount_input" value="0.00">
                        </div>

                        <div style="margin-bottom:1.5rem; font-size:0.825rem; color:var(--slate-400);">
                            <p style="margin-bottom:0.4rem;"><i class="fa fa-shield-alt" style="color:var(--primary);"></i> Fixed municipal tariff (No hidden surcharges)</p>
                            <p style="margin-bottom:0.4rem;"><i class="fa fa-check-circle" style="color:var(--primary);"></i> M-Pesa receipt generated immediately</p>
                            <p style="margin-bottom:0;"><i class="fa fa-clock" style="color:var(--primary);"></i> SMS alert sent 30 mins before truck arrives</p>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block btn-lg">
                            <i class="fa fa-check-circle"></i> Confirm & Book Pickup
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</main>

<?php require_once __DIR__ . '/includes/user_footer.php'; ?>
