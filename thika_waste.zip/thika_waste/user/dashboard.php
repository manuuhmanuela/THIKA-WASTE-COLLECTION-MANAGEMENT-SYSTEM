<?php
// user/dashboard.php - Resident Overview Dashboard
define('PAGE_TITLE', 'Resident Dashboard | Thika Waste Management');
require_once __DIR__ . '/includes/user_header.php';

$userId = $user['id'];

// Fetch user statistics
try {
    // Total requests
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM collection_requests WHERE user_id = ?");
    $stmt->execute([$userId]);
    $totalRequests = $stmt->fetchColumn();

    // Pending requests
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM collection_requests WHERE user_id = ? AND status = 'Pending'");
    $stmt->execute([$userId]);
    $pendingRequests = $stmt->fetchColumn();

    // Completed requests
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM collection_requests WHERE user_id = ? AND status = 'Completed'");
    $stmt->execute([$userId]);
    $completedRequests = $stmt->fetchColumn();

    // Total spent
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE user_id = ? AND payment_status = 'Completed'");
    $stmt->execute([$userId]);
    $totalSpent = $stmt->fetchColumn();

    // Recent Requests
    $stmt = $pdo->prepare("
        SELECT cr.*, wc.name AS category_name, wc.unit AS category_unit 
        FROM collection_requests cr
        JOIN waste_categories wc ON cr.category_id = wc.id
        WHERE cr.user_id = ?
        ORDER BY cr.id DESC LIMIT 5
    ");
    $stmt->execute([$userId]);
    $recentRequests = $stmt->fetchAll();

    // Latest Reminders & Notifications
    $stmt = $pdo->prepare("
        SELECT * FROM notifications 
        WHERE (user_id = ? OR user_id IS NULL)
        ORDER BY id DESC LIMIT 3
    ");
    $stmt->execute([$userId]);
    $recentAlerts = $stmt->fetchAll();

} catch (Exception $e) {
    die("Error loading dashboard data: " . $e->getMessage());
}
?>

<main class="main-content">
    <div class="container">
        <!-- Welcome Hero -->
        <div class="card" style="background:linear-gradient(135deg, #065f46 0%, #047857 100%); color:var(--white); border:none; padding:2rem; margin-bottom:2rem;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1.5rem;">
                <div>
                    <span class="badge badge-warning" style="margin-bottom:0.75rem;"><i class="fa fa-map-marker-alt"></i> Resident of <?= htmlspecialchars($user['estate']) ?></span>
                    <h2 style="color:var(--white); margin-bottom:0.5rem;">Habari, <?= htmlspecialchars($user['name']) ?>!</h2>
                    <p style="color:#a7f3d0; margin-bottom:0; max-width:600px;">
                        Manage your solid waste collection requests, track municipal truck arrivals, and keep your neighbourhood clean and eco-friendly.
                    </p>
                </div>
                <div style="display:flex; gap:0.75rem; flex-wrap:wrap;">
                    <a href="<?= $baseUrl ?>/user/request_collection.php" class="btn btn-lg btn-success" style="background:#10b981;">
                        <i class="fa fa-calendar-plus"></i> Collect Garbage
                    </a>
                    <a href="<?= $baseUrl ?>/user/track.php" class="btn btn-lg btn-secondary">
                        <i class="fa fa-route"></i> Track My Pickups
                    </a>
                </div>
            </div>
        </div>

        <!-- Metric Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon stat-icon-primary"><i class="fa fa-clipboard-list"></i></div>
                <div>
                    <div class="stat-number"><?= number_format($totalRequests) ?></div>
                    <div class="stat-label">Total Requests</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon stat-icon-warning"><i class="fa fa-clock"></i></div>
                <div>
                    <div class="stat-number"><?= number_format($pendingRequests) ?></div>
                    <div class="stat-label">Pending Pickups</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon stat-icon-success"><i class="fa fa-check-circle"></i></div>
                <div>
                    <div class="stat-number"><?= number_format($completedRequests) ?></div>
                    <div class="stat-label">Completed Pickups</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon stat-icon-info"><i class="fa fa-money-bill-wave"></i></div>
                <div>
                    <div class="stat-number"><?= formatKES($totalSpent) ?></div>
                    <div class="stat-label">Total Amount Paid</div>
                </div>
            </div>
        </div>

        <!-- Split Grid: Recent Pickups & Notifications -->
        <div style="display:grid; grid-template-columns: 2fr 1fr; gap:1.75rem;">
            <!-- Left: Recent Collection Requests -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fa fa-truck-pickup" style="color:var(--primary); margin-right:8px;"></i> My Recent Collections</h3>
                    <a href="<?= $baseUrl ?>/user/track.php" class="btn btn-sm btn-outline-primary">View All & Track</a>
                </div>

                <?php if (empty($recentRequests)): ?>
                    <div style="text-align:center; padding:3rem 1rem;">
                        <i class="fa fa-trash-restore-alt" style="font-size:3rem; color:var(--slate-300); margin-bottom:1rem;"></i>
                        <h4>No Garbage Pickups Scheduled Yet</h4>
                        <p style="color:var(--slate-400); font-size:0.9rem;">You have not placed any waste collection requests.</p>
                        <a href="<?= $baseUrl ?>/user/request_collection.php" class="btn btn-primary" style="margin-top:0.5rem;">
                            <i class="fa fa-calendar-plus"></i> Schedule First Pickup
                        </a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Req #</th>
                                    <th>Waste Category</th>
                                    <th>Pickup Date & Slot</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentRequests as $req): ?>
                                    <tr>
                                        <td><strong>#<?= $req['id'] ?></strong></td>
                                        <td>
                                            <strong><?= htmlspecialchars($req['category_name']) ?></strong>
                                            <div style="font-size:0.75rem; color:var(--slate-400);"><?= $req['quantity'] ?> <?= htmlspecialchars($req['category_unit']) ?></div>
                                        </td>
                                        <td>
                                            <div><i class="fa fa-calendar-alt" style="color:var(--slate-400);"></i> <?= date('d M Y', strtotime($req['pickup_date'])) ?></div>
                                            <div style="font-size:0.75rem; color:var(--slate-400);"><?= htmlspecialchars($req['pickup_time_slot']) ?></div>
                                        </td>
                                        <td>
                                            <strong><?= formatKES($req['total_amount']) ?></strong>
                                            <div><?= statusBadge($req['payment_status']) ?></div>
                                        </td>
                                        <td><?= statusBadge($req['status']) ?></td>
                                        <td>
                                            <a href="<?= $baseUrl ?>/user/track.php?id=<?= $req['id'] ?>" class="btn btn-sm btn-outline-primary" title="View Timeline">
                                                <i class="fa fa-eye"></i> Track
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Right: Latest Reminders & Admin Announcements -->
            <div>
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fa fa-bell" style="color:var(--accent); margin-right:8px;"></i> Recent Alerts</h3>
                        <a href="<?= $baseUrl ?>/user/notifications.php" class="btn btn-sm btn-secondary">View All</a>
                    </div>

                    <?php if (empty($recentAlerts)): ?>
                        <p style="color:var(--slate-400); font-size:0.9rem; text-align:center; padding:1.5rem 0;">No active alerts at the moment.</p>
                    <?php else: ?>
                        <div style="display:flex; flex-direction:column; gap:1rem;">
                            <?php foreach ($recentAlerts as $alert): ?>
                                <div style="background:var(--slate-50); border:1px solid var(--slate-200); border-left:4px solid <?= ($alert['type'] === 'reminder' ? 'var(--accent)' : ($alert['type'] === 'payment' ? 'var(--primary)' : 'var(--info)')) ?>; border-radius:var(--radius-md); padding:0.875rem;">
                                    <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.25rem;">
                                        <strong style="font-size:0.9rem; color:var(--dark);"><?= htmlspecialchars($alert['title']) ?></strong>
                                        <?php if (!$alert['is_read']): ?>
                                            <span class="badge badge-danger" style="font-size:0.65rem;">New</span>
                                        <?php endif; ?>
                                    </div>
                                    <p style="font-size:0.825rem; color:var(--slate-600); margin:0 0 0.5rem 0;">
                                        <?= htmlspecialchars($alert['message']) ?>
                                    </p>
                                    <small style="color:var(--slate-400); font-size:0.75rem;">
                                        <i class="fa fa-clock"></i> <?= date('M d, H:i', strtotime($alert['created_at'])) ?>
                                    </small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Emergency Contact Widget -->
                <div class="card" style="background:#f0fdf4; border:1px solid #bbf7d0;">
                    <div style="display:flex; gap:1rem; align-items:center;">
                        <div class="stat-icon stat-icon-success"><i class="fa fa-headset"></i></div>
                        <div>
                            <strong style="color:#166534; font-size:0.95rem;">Need Support in Thika?</strong>
                            <p style="color:#15803d; font-size:0.8rem; margin:0;">
                                Send an instant message to our dispatch admin anytime.
                            </p>
                        </div>
                    </div>
                    <a href="<?= $baseUrl ?>/user/messages.php" class="btn btn-sm btn-success btn-block" style="margin-top:1rem;">
                        <i class="fa fa-comment-alt"></i> Message Admin
                    </a>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/includes/user_footer.php'; ?>
