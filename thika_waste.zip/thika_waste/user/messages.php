<?php
// user/messages.php - Resident-to-Admin Messaging & Communication
require_once __DIR__ . '/includes/bootstrap.php';

$userId = $user['id'];
$refRequestId = (int)($_GET['ref'] ?? 0);
$defaultSubject = $refRequestId > 0 ? 'Inquiry regarding Collection Request #' . $refRequestId : '';

// Mark all admin messages as read when resident opens messages page
try {
    $pdo->prepare("UPDATE messages SET is_read = 1 WHERE user_id = ? AND sender_type = 'admin'")->execute([$userId]);
} catch (Exception $e) {}

// Handle Message Send
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($subject)) $errors[] = 'Subject line is required.';
    if (empty($message)) $errors[] = 'Message content cannot be blank.';

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO messages (user_id, sender_type, subject, message, is_read) VALUES (?, 'user', ?, ?, 0)");
            $stmt->execute([$userId, $subject, $message]);

            setFlash('success', 'Your message has been sent to our Thika dispatch office. We will reply shortly.');
            header('Location: ' . $baseUrl . '/user/messages.php');
            exit;
        } catch (Exception $e) {
            $errors[] = 'Failed to send message: ' . $e->getMessage();
        }
    }
}

define('PAGE_TITLE', 'Support Messages | Thika Waste Management');
require_once __DIR__ . '/includes/user_header.php';

// Fetch all conversation history
try {
    $stmt = $pdo->prepare("SELECT * FROM messages WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$userId]);
    $messages = $stmt->fetchAll();
} catch (Exception $e) {
    die("Error fetching messages: " . $e->getMessage());
}
?>

<main class="main-content">
    <div class="container">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
            <div>
                <h2><i class="fa fa-comments" style="color:var(--primary); margin-right:8px;"></i> Customer Support & Admin Chat</h2>
                <p style="margin:0;">Communicate directly with our Thika municipal operations dispatch desk.</p>
            </div>
            <a href="<?= $baseUrl ?>/user/request_collection.php" class="btn btn-outline-primary">
                <i class="fa fa-truck-pickup"></i> Schedule Collection
            </a>
        </div>

        <div style="display:grid; grid-template-columns: 1fr 1.5fr; gap:2rem;">
            <!-- Message Send Form -->
            <div class="card" style="padding:2rem;">
                <div class="card-header" style="padding-top:0;">
                    <h3><i class="fa fa-paper-plane" style="color:var(--primary); margin-right:8px;"></i> Send Message to Admin</h3>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul style="margin:0; padding-left:1.25rem;">
                            <?php foreach ($errors as $err): ?>
                                <li><?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?= $baseUrl ?>/user/messages.php" method="POST">
                    <div class="form-group">
                        <label class="form-label">Subject <span style="color:var(--danger);">*</span></label>
                        <input type="text" name="subject" class="form-control" placeholder="e.g. Delay in collection / Special bin request" value="<?= htmlspecialchars($_POST['subject'] ?? $defaultSubject) ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Message Content <span style="color:var(--danger);">*</span></label>
                        <textarea name="message" class="form-control" rows="6" placeholder="Type your inquiry, feedback, or special instructions here..." required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block btn-lg">
                        <i class="fa fa-paper-plane"></i> Send to Admin Desk
                    </button>
                </form>

                <div style="background:var(--slate-100); border-radius:var(--radius-md); padding:1rem; margin-top:1.5rem; font-size:0.825rem; color:var(--slate-600);">
                    <i class="fa fa-clock" style="color:var(--primary);"></i>
                    Our Thika operations center operates <strong>7:00 AM – 6:00 PM</strong> daily. Inquiries submitted after-hours are prioritized the following morning.
                </div>
            </div>

            <!-- Message History Timeline -->
            <div class="card" style="padding:2rem;">
                <div class="card-header" style="padding-top:0;">
                    <h3><i class="fa fa-history" style="color:var(--primary); margin-right:8px;"></i> Conversation History</h3>
                </div>

                <?php if (empty($messages)): ?>
                    <div style="text-align:center; padding:3rem 1rem;">
                        <i class="fa fa-comment-dots" style="font-size:3rem; color:var(--slate-300); margin-bottom:1rem;"></i>
                        <h4>No Messages Yet</h4>
                        <p style="color:var(--slate-400); font-size:0.9rem;">
                            You have not initiated any conversations with Thika Waste operations.
                        </p>
                    </div>
                <?php else: ?>
                    <div style="display:flex; flex-direction:column; gap:1.25rem;">
                        <?php foreach ($messages as $msg): ?>
                            <?php $isAdmin = ($msg['sender_type'] === 'admin'); ?>
                            <div style="background: <?= $isAdmin ? '#f0fdf4' : '#f8fafc' ?>; border:1px solid <?= $isAdmin ? '#bbf7d0' : '#e2e8f0' ?>; border-left:4px solid <?= $isAdmin ? 'var(--primary)' : 'var(--secondary)' ?>; border-radius:var(--radius-md); padding:1.25rem;">
                                <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.5rem;">
                                    <div>
                                        <span class="badge <?= $isAdmin ? 'badge-success' : 'badge-primary' ?>" style="font-size:0.75rem; margin-bottom:0.35rem;">
                                            <i class="fa <?= $isAdmin ? 'fa-shield-alt' : 'fa-user' ?>"></i> <?= $isAdmin ? 'Thika Waste Operations Desk' : 'You (Resident)' ?>
                                        </span>
                                        <h4 style="margin:0; font-size:1.05rem;"><?= htmlspecialchars($msg['subject']) ?></h4>
                                    </div>
                                    <small style="color:var(--slate-400); font-size:0.75rem; white-space:nowrap;">
                                        <i class="fa fa-clock"></i> <?= date('d M Y, H:i', strtotime($msg['created_at'])) ?>
                                    </small>
                                </div>
                                <div style="font-size:0.9rem; color:var(--slate-600); line-height:1.6; white-space:pre-line;">
                                    <?= htmlspecialchars($msg['message']) ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/includes/user_footer.php'; ?>
