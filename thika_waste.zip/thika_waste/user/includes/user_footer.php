<?php
// user/includes/user_footer.php
$baseUrl = getBaseUrl();
?>
<footer style="background:var(--white); border-top:1px solid var(--slate-200); padding:1.5rem 0; margin-top:auto; font-size:0.85rem; color:var(--slate-400);">
    <div class="container" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
        <div>
            &copy; <?= date('Y') ?> <strong>Thika Clean Waste Management</strong> &bull; Resident Service Portal
        </div>
        <div>
            <i class="fa fa-phone" style="color:var(--primary); margin-right:4px;"></i> Customer Support: <strong>+254 712 345 678</strong> | Thika, Kenya
        </div>
    </div>
</footer>

<script src="<?= $baseUrl ?>/assets/js/main.js"></script>
</body>
</html>
