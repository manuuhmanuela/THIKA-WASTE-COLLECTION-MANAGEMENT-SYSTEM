<?php
// user/includes/user_header.php - Dedicated User Navigation & Header
require_once __DIR__ . '/bootstrap.php';

$currentScript = basename($_SERVER['SCRIPT_NAME']);

// Live notification and message count
$unreadNotifs = getUnreadNotificationsCount($pdo, $user['id']);
$unreadMessages = getUnreadMessagesCount($pdo, $user['id']);

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= defined('PAGE_TITLE') ? htmlspecialchars(PAGE_TITLE) : 'Resident Portal | Thika Waste' ?></title>
    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
</head>
<body>

<!-- User Header Navigation -->
<header class="user-header">
    <div class="container">
        <div class="user-nav-inner">
            <div style="display:flex; align-items:center; gap:2rem;">
                <a href="<?= $baseUrl ?>/user/dashboard.php" class="brand-logo">
                    <div class="brand-icon">
                        <i class="fa fa-recycle"></i>
                    </div>
                    <span>Thika<strong style="color:var(--primary);">Clean</strong> <span style="font-size:0.75rem; background:var(--primary-light); color:var(--primary); padding:2px 8px; border-radius:12px; vertical-align:middle;">Resident</span></span>
                </a>

                <ul class="user-nav-links">
                    <li class="user-nav-item <?= ($currentScript === 'dashboard.php') ? 'active' : '' ?>">
                        <a href="<?= $baseUrl ?>/user/dashboard.php"><i class="fa fa-th-large"></i> Dashboard</a>
                    </li>
                    <li class="user-nav-item <?= ($currentScript === 'request_collection.php') ? 'active' : '' ?>">
                        <a href="<?= $baseUrl ?>/user/request_collection.php"><i class="fa fa-calendar-plus"></i> Collect Garbage</a>
                    </li>
                    <li class="user-nav-item <?= ($currentScript === 'track.php') ? 'active' : '' ?>">
                        <a href="<?= $baseUrl ?>/user/track.php"><i class="fa fa-route"></i> Track Pickups</a>
                    </li>
                    <li class="user-nav-item <?= ($currentScript === 'payments.php') ? 'active' : '' ?>">
                        <a href="<?= $baseUrl ?>/user/payments.php"><i class="fa fa-credit-card"></i> Payments</a>
                    </li>
                    <li class="user-nav-item <?= ($currentScript === 'messages.php') ? 'active' : '' ?>">
                        <a href="<?= $baseUrl ?>/user/messages.php">
                            <i class="fa fa-comments"></i> Admin Chat
                            <?php if ($unreadMessages > 0): ?>
                                <span class="notification-pill"><?= $unreadMessages ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="user-nav-item <?= ($currentScript === 'notifications.php') ? 'active' : '' ?>">
                        <a href="<?= $baseUrl ?>/user/notifications.php">
                            <i class="fa fa-bell"></i> Alerts
                            <?php if ($unreadNotifs > 0): ?>
                                <span class="notification-pill"><?= $unreadNotifs ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </div>

            <div style="display:flex; align-items:center; gap:1.25rem;">
                <div style="display:flex; align-items:center; gap:0.6rem; text-align:right;">
                    <div>
                        <div style="font-size:0.875rem; font-weight:700; color:var(--dark);"><?= htmlspecialchars($user['name']) ?></div>
                        <div style="font-size:0.75rem; color:var(--slate-400);"><i class="fa fa-map-marker-alt" style="color:var(--primary);"></i> <?= htmlspecialchars($user['estate']) ?></div>
                    </div>
                    <div style="width:36px; height:36px; border-radius:50%; background:var(--primary-light); color:var(--primary); display:flex; align-items:center; justify-content:center; font-weight:700;">
                        <?= strtoupper(substr($user['name'], 0, 1)) ?>
                    </div>
                </div>

                <a href="<?= $baseUrl ?>/logout.php" class="btn btn-sm btn-secondary" title="Sign Out">
                    <i class="fa fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </div>
</header>

<?php if ($flash): ?>
<div class="container" style="margin-top: 1.25rem;">
    <div class="alert alert-<?= htmlspecialchars($flash['type']) ?>">
        <span><?= htmlspecialchars($flash['message']) ?></span>
        <button class="alert-close">&times;</button>
    </div>
</div>
<?php endif; ?>
