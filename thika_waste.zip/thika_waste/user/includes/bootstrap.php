<?php
// user/includes/bootstrap.php - Clean user backend bootstrapping without HTML output
require_once __DIR__ . '/../../config/auth.php';
requireLogin('/login.php');

$user = currentUser();
$baseUrl = getBaseUrl();
