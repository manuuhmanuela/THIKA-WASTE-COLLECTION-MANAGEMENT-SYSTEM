<?php
// register.php - Resident Account Registration
define('PAGE_TITLE', 'Resident Registration | Thika Waste Management');
require_once __DIR__ . '/config/auth.php';

if (isLoggedIn()) {
    header('Location: ' . $baseUrl . (isAdmin() ? '/admin/index.php' : '/user/dashboard.php'));
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $estate = trim($_POST['estate'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Validation
    if (empty($name)) $errors[] = 'Full name is required.';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email address is required.';
    if (empty($phone)) $errors[] = 'Phone number is required.';
    if (empty($estate)) $errors[] = 'Please select your estate / zone in Thika.';
    if (empty($address)) $errors[] = 'Physical address or house number is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $password_confirm) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        try {
            // Check email uniqueness
            $chk = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $chk->execute([$email]);
            if ($chk->fetch()) {
                $errors[] = 'An account with that email address already exists. Please log in.';
            } else {
                $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, estate, address, role, password, status) VALUES (?, ?, ?, ?, ?, 'user', ?, 'active')");
                $stmt->execute([$name, $email, $phone, $estate, $address, $hashedPassword]);
                $newUserId = $pdo->lastInsertId();

                // Send welcome notification
                $notifStmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'general')");
                $notifStmt->execute([
                    $newUserId,
                    'Welcome to Thika Waste Management',
                    'Your resident account is ready! You can now schedule garbage pickups, track collection vehicles, and manage payments easily.'
                ]);

                // Auto-login
                $_SESSION['user_id'] = $newUserId;
                $_SESSION['user_name'] = $name;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_phone'] = $phone;
                $_SESSION['user_role'] = 'user';
                $_SESSION['user_estate'] = $estate;

                setFlash('success', 'Registration successful! Welcome to Thika Clean Waste.');
                header('Location: ' . $baseUrl . '/user/dashboard.php');
                exit;
            }
        } catch (Exception $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<main class="main-content" style="display:flex; align-items:center;">
    <div class="container" style="max-width: 650px;">
        <div class="card" style="padding: 2.5rem; box-shadow: var(--shadow-lg);">
            <div style="text-align:center; margin-bottom: 2rem;">
                <div class="brand-icon" style="margin: 0 auto 1rem; width: 50px; height: 50px;">
                    <i class="fa fa-user-plus"></i>
                </div>
                <h2>Resident Registration</h2>
                <p>Register your household or business in Thika to schedule garbage collection and receive pickup reminders.</p>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul style="margin:0; padding-left:1.25rem;">
                        <?php foreach ($errors as $err): ?>
                            <li><?= htmlspecialchars($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?= $baseUrl ?>/register.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Full Name <span style="color:var(--danger);">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Samuel Mutua" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email Address <span style="color:var(--danger);">*</span></label>
                        <input type="email" name="email" class="form-control" placeholder="samuel@gmail.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Phone Number (M-Pesa) <span style="color:var(--danger);">*</span></label>
                        <input type="tel" name="phone" class="form-control" placeholder="0712345678" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Thika Estate / Zone <span style="color:var(--danger);">*</span></label>
                        <select name="estate" class="form-control" required>
                            <option value="">-- Choose Your Estate --</option>
                            <?php foreach (getThikaZones() as $zone): ?>
                                <option value="<?= htmlspecialchars($zone) ?>" <?= (($_POST['estate'] ?? '') === $zone) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($zone) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Physical Address / Street / House No. <span style="color:var(--danger);">*</span></label>
                    <input type="text" name="address" class="form-control" placeholder="e.g. Block C, Flat 12, Behind Chania High Gate" value="<?= htmlspecialchars($_POST['address'] ?? '') ?>" required>
                    <small class="form-help">This helps our waste pickup drivers locate your garbage collection point easily.</small>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Create Password <span style="color:var(--danger);">*</span></label>
                        <input type="password" name="password" class="form-control" placeholder="Minimum 6 characters" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Confirm Password <span style="color:var(--danger);">*</span></label>
                        <input type="password" name="password_confirm" class="form-control" placeholder="Re-type password" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:1rem;">
                    <i class="fa fa-user-check"></i> Complete Registration
                </button>
            </form>

            <div style="text-align:center; margin-top:1.5rem; font-size:0.9rem; color:var(--slate-600);">
                Already have an account? <a href="<?= $baseUrl ?>/login.php" style="font-weight:600;">Login here</a>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
