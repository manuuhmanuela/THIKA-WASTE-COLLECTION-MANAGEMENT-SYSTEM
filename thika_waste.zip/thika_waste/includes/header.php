<?php
// includes/header.php
if (!defined('PAGE_TITLE')) {
    define('PAGE_TITLE', 'Thika Waste Management | Clean, Reliable & Eco-Friendly Garbage Collection');
}
require_once __DIR__ . '/../config/auth.php';
$baseUrl = getBaseUrl();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars(PAGE_TITLE) ?></title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom Style -->
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
</head>
<body>

<?php if ($flash): ?>
<div class="container" style="margin-top: 1rem;">
    <div class="alert alert-<?= htmlspecialchars($flash['type']) ?>">
        <span><?= htmlspecialchars($flash['message']) ?></span>
        <button class="alert-close">&times;</button>
    </div>
</div>
<?php endif; ?>
