<?php
// includes/footer.php
$baseUrl = getBaseUrl();
?>
<footer class="footer-public">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-col">
                <a href="<?= $baseUrl ?>/index.php" class="brand-logo" style="color:var(--white); margin-bottom:1rem;">
                    <div class="brand-icon">
                        <i class="fa fa-recycle"></i>
                    </div>
                    <span>Thika<strong style="color:var(--primary);">Clean</strong></span>
                </a>
                <p style="color:var(--slate-400); font-size:0.9rem;">
                    Providing modern, reliable, and sustainable solid waste collection, recyclable sorting, and environmental management across Thika Sub-County and surrounding Kiambu County areas.
                </p>
                <div style="display:flex; gap:0.75rem; margin-top:1rem;">
                    <a href="#" style="color:var(--white); background:rgba(255,255,255,0.1); width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%;"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" style="color:var(--white); background:rgba(255,255,255,0.1); width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%;"><i class="fab fa-twitter"></i></a>
                    <a href="#" style="color:var(--white); background:rgba(255,255,255,0.1); width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%;"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>

            <div class="footer-col">
                <h4>Quick Links</h4>
                <ul class="footer-links">
                    <li><a href="<?= $baseUrl ?>/index.php">Home</a></li>
                    <li><a href="<?= $baseUrl ?>/services.php">Our Services</a></li>
                    <li><a href="<?= $baseUrl ?>/contact.php">Contact & Support</a></li>
                    <li><a href="<?= $baseUrl ?>/register.php">Resident Registration</a></li>
                    <li><a href="<?= $baseUrl ?>/login.php">Resident / Admin Login</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Thika Coverage Zones</h4>
                <ul class="footer-links" style="font-size:0.875rem;">
                    <li><i class="fa fa-map-marker-alt" style="color:var(--primary); margin-right:5px;"></i> Thika Town CBD</li>
                    <li><i class="fa fa-map-marker-alt" style="color:var(--primary); margin-right:5px;"></i> Section 9 & Mama Ngina</li>
                    <li><i class="fa fa-map-marker-alt" style="color:var(--primary); margin-right:5px;"></i> Makongeni Phases 1 - 5</li>
                    <li><i class="fa fa-map-marker-alt" style="color:var(--primary); margin-right:5px;"></i> Ngoingwa & M-Pesa Foundation Area</li>
                    <li><i class="fa fa-map-marker-alt" style="color:var(--primary); margin-right:5px;"></i> Landless & BAT Area</li>
                    <li><i class="fa fa-map-marker-alt" style="color:var(--primary); margin-right:5px;"></i> Chania, Kisii & Kiganjo</li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Head Office</h4>
                <p style="color:var(--slate-400); font-size:0.9rem; margin-bottom:0.5rem;">
                    <i class="fa fa-building" style="color:var(--primary); margin-right:6px;"></i> Municipal Commercial Plaza, 2nd Floor, Kenyatta Highway, Thika, Kenya
                </p>
                <p style="color:var(--slate-400); font-size:0.9rem; margin-bottom:0.5rem;">
                    <i class="fa fa-phone" style="color:var(--primary); margin-right:6px;"></i> +254 (0) 712 345 678
                </p>
                <p style="color:var(--slate-400); font-size:0.9rem; margin-bottom:0.5rem;">
                    <i class="fa fa-envelope" style="color:var(--primary); margin-right:6px;"></i> info@thikawaste.co.ke
                </p>
                <div style="background:rgba(5,150,105,0.15); border:1px solid rgba(5,150,105,0.4); padding:0.75rem; border-radius:var(--radius-md); margin-top:0.75rem;">
                    <small style="color:var(--white); font-weight:600;"><i class="fa fa-truck-pickup" style="color:var(--primary);"></i> 24/7 Bulk Waste Hotline</small>
                    <div style="color:#34d399; font-weight:700; font-size:1rem;">0700-CLEAN-THIKA</div>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <div>
                &copy; <?= date('Y') ?> Thika Clean Waste Management System. All rights reserved.
            </div>
            <div>
                Designed for Sustainable & Eco-friendly Kiambu County Urban Spaces
            </div>
        </div>
    </div>
</footer>

<!-- Scripts -->
<script src="<?= $baseUrl ?>/assets/js/main.js"></script>
</body>
</html>
