<?php
// includes/navbar.php - Public Navigation Header
$currentScript = basename($_SERVER['SCRIPT_NAME']);
$baseUrl = getBaseUrl();
?>
<header class="navbar-public">
    <div class="container">
        <div class="navbar-inner">
            <a href="<?= $baseUrl ?>/index.php" class="brand-logo">
                <div class="brand-icon">
                    <i class="fa fa-recycle"></i>
                </div>
                <span>Thika<strong style="color:var(--primary);">Clean</strong></span>
            </a>

            <button class="mobile-toggle" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>

            <ul class="nav-links">
                <li><a href="<?= $baseUrl ?>/index.php" class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>">Home</a></li>
                <li><a href="<?= $baseUrl ?>/services.php" class="nav-link <?= ($currentScript === 'services.php') ? 'active' : '' ?>">Our Services</a></li>
                <li><a href="<?= $baseUrl ?>/contact.php" class="nav-link <?= ($currentScript === 'contact.php') ? 'active' : '' ?>">Contact Us</a></li>
                
                <?php if (isLoggedIn()): ?>
                    <?php if (isAdmin()): ?>
                        <li><a href="<?= $baseUrl ?>/admin/index.php" class="btn btn-sm btn-primary"><i class="fa fa-shield-alt"></i> Go to Admin Portal</a></li>
                        <li><a href="<?= $baseUrl ?>/logout.php" class="btn btn-sm btn-secondary"><i class="fa fa-sign-out-alt"></i> Logout</a></li>
                    <?php else: ?>
                        <li><a href="<?= $baseUrl ?>/user/dashboard.php" class="btn btn-sm btn-outline-primary"><i class="fa fa-columns"></i> Resident Dashboard</a></li>
                        <li><a href="<?= $baseUrl ?>/user/request_collection.php" class="btn btn-sm btn-primary"><i class="fa fa-plus-circle"></i> Book Pickup</a></li>
                        <li><a href="<?= $baseUrl ?>/logout.php" class="btn btn-sm btn-secondary"><i class="fa fa-sign-out-alt"></i> Logout</a></li>
                    <?php endif; ?>
                <?php else: ?>
                    <li><a href="<?= $baseUrl ?>/login.php" class="nav-link <?= ($currentScript === 'login.php') ? 'active' : '' ?>"><i class="fa fa-user-circle"></i> Login</a></li>
                    <li><a href="<?= $baseUrl ?>/register.php" class="btn btn-sm btn-secondary <?= ($currentScript === 'register.php') ? 'active' : '' ?>">Register</a></li>
                    <li><a href="<?= $baseUrl ?>/login.php?redirect=user/request_collection.php" class="btn btn-sm btn-primary"><i class="fa fa-truck-pickup"></i> Schedule Pickup</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</header>
