<?php
// logout.php - Session Destruction
require_once __DIR__ . '/config/auth.php';

$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

session_start();
setFlash('info', 'You have been logged out successfully.');
header('Location: ' . getBaseUrl() . '/login.php');
exit;
