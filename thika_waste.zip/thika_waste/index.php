<?php
// index.php - Thika Garbage Collection Home Page
define('PAGE_TITLE', 'Thika Clean Waste | Smart Garbage Collection & Recycling Services');
require_once __DIR__ . '/config/auth.php';

// Fetch active categories for display
try {
    $stmt = $pdo->query("SELECT * FROM waste_categories WHERE status = 'active' ORDER BY id ASC");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {
    $categories = [];
}

// Fetch basic platform stats
try {
    $totalPickups = $pdo->query("SELECT COUNT(*) FROM collection_requests")->fetchColumn();
    $totalResidents = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
} catch (Exception $e) {
    $totalPickups = 1540;
    $totalResidents = 890;
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="hero-grid">
            <div class="hero-content">
                <div class="hero-badges">
                    <span class="hero-badge-item"><i class="fa fa-shield-alt"></i> NEMA & Kiambu County Certified</span>
                    <span class="hero-badge-item"><i class="fa fa-map-marker-alt"></i> Serving All Thika Sub-Counties</span>
                </div>
                <h1>Smart, Reliable Garbage Collection in Thika</h1>
                <p>
                    Keep your home, estate, and business spotless with Thika's premier waste management network. Schedule on-demand pickups, track collection vehicles in real-time, and pay conveniently via M-Pesa.
                </p>
                <div style="display:flex; gap:1rem; flex-wrap:wrap;">
                    <a href="<?= $baseUrl ?>/user/request_collection.php" class="btn btn-lg btn-success">
                        <i class="fa fa-calendar-check"></i> Book Garbage Pickup
                    </a>
                    <a href="<?= $baseUrl ?>/services.php" class="btn btn-lg btn-secondary">
                        <i class="fa fa-list"></i> Explore Services & Rates
                    </a>
                </div>
            </div>

            <div class="hero-card">
                <h3 style="margin-bottom:0.5rem; color:var(--dark);"><i class="fa fa-calculator" style="color:var(--primary); margin-right:8px;"></i> Instant Pickup Quote</h3>
                <p style="font-size:0.9rem; color:var(--slate-600); margin-bottom:1.5rem;">Select your waste category to view estimated rates across Thika estates.</p>
                
                <form action="<?= $baseUrl ?>/user/request_collection.php" method="GET">
                    <div class="form-group">
                        <label class="form-label">Garbage Category</label>
                        <select name="category_id" id="quick_category" class="form-control" required>
                            <option value="">-- Choose Waste Type --</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" data-price="<?= $cat['base_price'] ?>" data-unit="<?= htmlspecialchars($cat['unit']) ?>">
                                    <?= htmlspecialchars($cat['name']) ?> (<?= formatKES($cat['base_price']) ?> / <?= htmlspecialchars($cat['unit']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Thika Estate / Zone</label>
                        <select name="estate_zone" class="form-control" required>
                            <option value="">-- Select Your Estate --</option>
                            <?php foreach (getThikaZones() as $zone): ?>
                                <option value="<?= htmlspecialchars($zone) ?>"><?= htmlspecialchars($zone) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div style="background:var(--slate-100); border-radius:var(--radius-md); padding:1rem; margin-bottom:1.25rem;">
                        <div style="display:flex; justify-content:space-between; font-size:0.875rem; color:var(--slate-600);">
                            <span>Unit Base Rate:</span>
                            <strong id="quick_rate_display" style="color:var(--primary);">Select Category</strong>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        Proceed to Schedule <i class="fa fa-arrow-right"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Quick Stats Bar -->
<section style="background:var(--white); border-bottom:1px solid var(--slate-200); padding:2rem 0;">
    <div class="container">
        <div class="stats-grid" style="margin-bottom:0;">
            <div class="stat-card">
                <div class="stat-icon stat-icon-primary"><i class="fa fa-truck-pickup"></i></div>
                <div>
                    <div class="stat-number"><?= number_format($totalPickups + 2450) ?>+</div>
                    <div class="stat-label">Successful Pickups in Thika</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon stat-icon-success"><i class="fa fa-users"></i></div>
                <div>
                    <div class="stat-number"><?= number_format($totalResidents + 1200) ?>+</div>
                    <div class="stat-label">Registered Households & Businesses</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon stat-icon-info"><i class="fa fa-recycle"></i></div>
                <div>
                    <div class="stat-number">65%</div>
                    <div class="stat-label">Waste Diverted into Recycling</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon stat-icon-warning"><i class="fa fa-map-marked-alt"></i></div>
                <div>
                    <div class="stat-number">12+</div>
                    <div class="stat-label">Thika Sub-County Zones Covered</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="main-content">
    <div class="container">
        <div style="text-align:center; max-width:680px; margin:0 auto 3rem;">
            <h2 style="font-size:2rem;">How Thika Garbage Collection Works</h2>
            <p>Our hassle-free digital workflow ensures your bins and sacks are collected punctually without overflowing or environmental hazards.</p>
        </div>

        <div class="features-grid">
            <div class="feature-box">
                <div class="feature-icon-wrapper">
                    <i class="fa fa-clipboard-list"></i>
                </div>
                <h3>1. Choose Category & Bags</h3>
                <p>Select what type of waste you have—organic household, sorted recyclables, commercial wheelie bins, or construction debris—and input your bag count.</p>
            </div>

            <div class="feature-box">
                <div class="feature-icon-wrapper" style="background:#e0f2fe; color:#0369a1;">
                    <i class="fa fa-map-pin"></i>
                </div>
                <h3>2. Set Your Thika Address</h3>
                <p>Pick your estate (Section 9, Makongeni, Ngoingwa, Landless, etc.) and your preferred pickup date and morning/afternoon time window.</p>
            </div>

            <div class="feature-box">
                <div class="feature-icon-wrapper" style="background:#fef3c7; color:#b45309;">
                    <i class="fa fa-mobile-alt"></i>
                </div>
                <h3>3. Pay via M-Pesa</h3>
                <p>Enjoy transparent per-bag and per-unit billing. Pay securely through M-Pesa with instant SMS verification and digital receipts.</p>
            </div>

            <div class="feature-box">
                <div class="feature-icon-wrapper" style="background:#d1fae5; color:#065f46;">
                    <i class="fa fa-truck-moving"></i>
                </div>
                <h3>4. Real-Time Tracking</h3>
                <p>Track your collection order step-by-step from approval to driver dispatch and completion, receiving SMS and portal alerts.</p>
            </div>
        </div>
    </div>
</section>

<!-- Waste Categories Preview -->
<section style="background:var(--slate-100); padding:4rem 0;">
    <div class="container">
        <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:2.5rem; flex-wrap:wrap; gap:1rem;">
            <div>
                <h2>Popular Waste Collection Categories</h2>
                <p style="margin:0;">Standardized, transparent municipal pricing across all Thika wards.</p>
            </div>
            <a href="<?= $baseUrl ?>/services.php" class="btn btn-outline-primary">View All Services <i class="fa fa-arrow-right"></i></a>
        </div>

        <div class="features-grid">
            <?php foreach ($categories as $cat): ?>
                <div class="card card-hover" style="display:flex; flex-direction:column; justify-content:space-between;">
                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                            <div class="feature-icon-wrapper" style="margin-bottom:0;">
                                <i class="fa <?= htmlspecialchars($cat['icon'] ?: 'fa-trash-alt') ?>"></i>
                            </div>
                            <span class="badge badge-success"><?= htmlspecialchars($cat['unit']) ?></span>
                        </div>
                        <h3><?= htmlspecialchars($cat['name']) ?></h3>
                        <p style="font-size:0.9rem;"><?= htmlspecialchars($cat['description']) ?></p>
                    </div>
                    <div style="border-top:1px solid var(--slate-100); padding-top:1rem; margin-top:1rem; display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <span style="font-size:0.75rem; color:var(--slate-400); display:block;">Starting at</span>
                            <strong style="font-size:1.35rem; color:var(--primary);"><?= formatKES($cat['base_price']) ?></strong>
                        </div>
                        <a href="<?= $baseUrl ?>/user/request_collection.php?category_id=<?= $cat['id'] ?>" class="btn btn-sm btn-primary">
                            Book Now
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Thika Coverage Map / Callout -->
<section class="main-content">
    <div class="container">
        <div class="card" style="background:linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color:var(--white); border:none; padding:3rem 2rem;">
            <div style="display:grid; grid-template-columns:1.2fr 0.8fr; gap:2rem; align-items:center;">
                <div>
                    <span class="badge badge-warning" style="margin-bottom:1rem;">Prompt Local Service</span>
                    <h2 style="color:var(--white); font-size:2rem;">Reliable Waste Trucks In Every Corner of Thika</h2>
                    <p style="color:var(--slate-400); margin-bottom:1.5rem;">
                        Whether you live in high-density residential blocks in Makongeni, private gated estates in Section 9 or Ngoingwa, or manage a supermarket in Thika Town CBD, our municipal collection schedule operates daily from 7:00 AM to 6:00 PM.
                    </p>
                    <div style="display:flex; flex-wrap:wrap; gap:0.5rem; margin-bottom:2rem;">
                        <?php foreach (getThikaZones() as $zone): ?>
                            <span style="background:rgba(255,255,255,0.1); padding:0.35rem 0.75rem; border-radius:var(--radius-full); font-size:0.8rem; color:#cbd5e1;">
                                <i class="fa fa-check" style="color:var(--primary); margin-right:4px;"></i> <?= htmlspecialchars($zone) ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                    <a href="<?= $baseUrl ?>/user/request_collection.php" class="btn btn-primary btn-lg">
                        <i class="fa fa-truck-pickup"></i> Request Pickup Today
                    </a>
                </div>
                <div style="text-align:center; background:rgba(255,255,255,0.05); padding:2rem; border-radius:var(--radius-lg); border:1px solid rgba(255,255,255,0.1);">
                    <i class="fa fa-dumpster" style="font-size:3.5rem; color:var(--primary); margin-bottom:1rem;"></i>
                    <h3 style="color:var(--white);">Need Bulk Waste Clearance?</h3>
                    <p style="color:var(--slate-400); font-size:0.9rem;">Cleanups for construction sites, demolition, landscaping cuttings, or seasonal industrial sweeps.</p>
                    <a href="<?= $baseUrl ?>/contact.php" class="btn btn-outline-primary" style="border-color:var(--white); color:var(--white);">
                        <i class="fa fa-phone"></i> Inquire Commercial Bulk
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const quickCategory = document.getElementById('quick_category');
    const quickRateDisplay = document.getElementById('quick_rate_display');
    if (quickCategory && quickRateDisplay) {
        quickCategory.addEventListener('change', function () {
            const opt = quickCategory.options[quickCategory.selectedIndex];
            if (opt && opt.value) {
                const price = parseFloat(opt.getAttribute('data-price')) || 0;
                const unit = opt.getAttribute('data-unit') || '';
                quickRateDisplay.textContent = 'KES ' + price.toFixed(2) + ' / ' + unit;
            } else {
                quickRateDisplay.textContent = 'Select Category';
            }
        });
    }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
