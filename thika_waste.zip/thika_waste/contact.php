<?php
// contact.php - Contact Thika Waste Management
define('PAGE_TITLE', 'Contact Us & Municipal Support | Thika Waste Management');
require_once __DIR__ . '/config/auth.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($name)) $errors[] = 'Full name is required.';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email address is required.';
    if (empty($phone)) $errors[] = 'Phone number is required.';
    if (empty($subject)) $errors[] = 'Subject is required.';
    if (empty($message)) $errors[] = 'Message content cannot be blank.';

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO contact_inquiries (name, email, phone, subject, message, status) VALUES (?, ?, ?, ?, ?, 'New')");
            $stmt->execute([$name, $email, $phone, $subject, $message]);
            setFlash('success', 'Thank you! Your message has been received by our Thika operations team. We will respond promptly.');
            header('Location: ' . $baseUrl . '/contact.php');
            exit;
        } catch (Exception $e) {
            $errors[] = 'Failed to submit inquiry: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<div style="background:var(--dark); color:var(--white); padding:3.5rem 0;">
    <div class="container text-center">
        <h1 style="color:var(--white); font-size:2.5rem;">Contact Thika Waste Operations</h1>
        <p style="color:var(--slate-400); max-width:600px; margin:0 auto;">
            Have a question about collection routes, bulky trash requests, or need a commercial bin in Thika? Reach out to our customer desk.
        </p>
    </div>
</div>

<main class="main-content">
    <div class="container">
        <div style="display:grid; grid-template-columns: 1fr 1.3fr; gap:2.5rem;">
            <!-- Contact Information Sidebar -->
            <div>
                <div class="card" style="padding:2rem;">
                    <h3>Get in Touch</h3>
                    <p style="font-size:0.925rem; color:var(--slate-600); margin-bottom:1.5rem;">
                        Our central operations dispatch monitors collection routes across all Thika wards 6 days a week.
                    </p>

                    <div style="display:flex; flex-direction:column; gap:1.25rem;">
                        <div style="display:flex; gap:1rem; align-items:flex-start;">
                            <div class="stat-icon stat-icon-primary" style="width:42px; height:42px; font-size:1.1rem; flex-shrink:0;">
                                <i class="fa fa-map-marker-alt"></i>
                            </div>
                            <div>
                                <strong style="display:block; font-size:0.95rem;">Central Operations Office</strong>
                                <span style="font-size:0.875rem; color:var(--slate-600);">Municipal Commercial Plaza, 2nd Floor, Kenyatta Highway, Thika Town</span>
                            </div>
                        </div>

                        <div style="display:flex; gap:1rem; align-items:flex-start;">
                            <div class="stat-icon stat-icon-info" style="width:42px; height:42px; font-size:1.1rem; flex-shrink:0;">
                                <i class="fa fa-phone-alt"></i>
                            </div>
                            <div>
                                <strong style="display:block; font-size:0.95rem;">Hotline & Enquiries</strong>
                                <span style="font-size:0.875rem; color:var(--slate-600);">+254 (0) 712 345 678 / +254 (0) 733 987 654</span>
                            </div>
                        </div>

                        <div style="display:flex; gap:1rem; align-items:flex-start;">
                            <div class="stat-icon stat-icon-success" style="width:42px; height:42px; font-size:1.1rem; flex-shrink:0;">
                                <i class="fab fa-whatsapp"></i>
                            </div>
                            <div>
                                <strong style="display:block; font-size:0.95rem;">WhatsApp Dispatch</strong>
                                <span style="font-size:0.875rem; color:var(--slate-600);">+254 700 253 264 (Instant Location Sharing)</span>
                            </div>
                        </div>

                        <div style="display:flex; gap:1rem; align-items:flex-start;">
                            <div class="stat-icon stat-icon-warning" style="width:42px; height:42px; font-size:1.1rem; flex-shrink:0;">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div>
                                <strong style="display:block; font-size:0.95rem;">Email Support</strong>
                                <span style="font-size:0.875rem; color:var(--slate-600);">support@thikawaste.co.ke / info@thikawaste.co.ke</span>
                            </div>
                        </div>
                    </div>

                    <hr style="border:0; border-top:1px solid var(--slate-200); margin:1.75rem 0;">

                    <h4>Operating Hours</h4>
                    <ul style="list-style:none; font-size:0.875rem; color:var(--slate-600);">
                        <li style="display:flex; justify-content:space-between; margin-bottom:0.35rem;">
                            <span>Monday – Friday:</span>
                            <strong>7:00 AM – 6:00 PM</strong>
                        </li>
                        <li style="display:flex; justify-content:space-between; margin-bottom:0.35rem;">
                            <span>Saturday:</span>
                            <strong>7:30 AM – 4:00 PM</strong>
                        </li>
                        <li style="display:flex; justify-content:space-between;">
                            <span>Sunday & Holidays:</span>
                            <strong style="color:var(--primary);">Emergency Bulk On-Call</strong>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="card" style="padding:2rem;">
                <div class="card-header" style="padding-top:0;">
                    <h3>Send Us an Inquiry</h3>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul style="margin:0; padding-left:1.25rem;">
                            <?php foreach ($errors as $err): ?>
                                <li><?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?= $baseUrl ?>/contact.php" method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Your Name <span style="color:var(--danger);">*</span></label>
                            <input type="text" name="name" class="form-control" placeholder="e.g. Samuel Mutua" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone Number <span style="color:var(--danger);">*</span></label>
                            <input type="tel" name="phone" class="form-control" placeholder="e.g. 0712345678" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Email Address <span style="color:var(--danger);">*</span></label>
                            <input type="email" name="email" class="form-control" placeholder="samuel@gmail.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Subject <span style="color:var(--danger);">*</span></label>
                            <input type="text" name="subject" class="form-control" placeholder="e.g. Requesting Commercial Bin in Ngoingwa" value="<?= htmlspecialchars($_POST['subject'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Message Details <span style="color:var(--danger);">*</span></label>
                        <textarea name="message" class="form-control" placeholder="Describe your location, estate in Thika, volume of waste, or any specific inquiry..." rows="5" required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fa fa-paper-plane"></i> Send Inquiry
                    </button>
                </form>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
