
| Administrator`admin@thikawaste.co.ke` | `admin123` |
|