-- Thika Waste Management System Database Schema
-- Database: thika_waste

CREATE DATABASE IF NOT EXISTS `thika_waste` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `thika_waste`;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `phone` VARCHAR(25) NOT NULL,
  `estate` VARCHAR(100) NOT NULL,
  `address` TEXT NOT NULL,
  `role` ENUM('user', 'admin') DEFAULT 'user',
  `password` VARCHAR(255) NOT NULL,
  `status` ENUM('active', 'suspended') DEFAULT 'active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Waste Categories Table
CREATE TABLE IF NOT EXISTS `waste_categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `unit` VARCHAR(50) NOT NULL DEFAULT 'Per 50kg Bag',
  `base_price` DECIMAL(10,2) NOT NULL DEFAULT 150.00,
  `icon` VARCHAR(50) DEFAULT 'fa-trash',
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Collection Requests Table
CREATE TABLE IF NOT EXISTS `collection_requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `category_id` INT NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `unit_price` DECIMAL(10,2) NOT NULL,
  `total_amount` DECIMAL(10,2) NOT NULL,
  `pickup_date` DATE NOT NULL,
  `pickup_time_slot` VARCHAR(50) NOT NULL DEFAULT 'Morning (8AM - 11AM)',
  `pickup_address` TEXT NOT NULL,
  `estate_zone` VARCHAR(100) NOT NULL,
  `notes` TEXT NULL,
  `status` ENUM('Pending', 'Approved', 'In Progress', 'Completed', 'Cancelled') DEFAULT 'Pending',
  `payment_status` ENUM('Unpaid', 'Paid', 'Pending Verification') DEFAULT 'Unpaid',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`category_id`) REFERENCES `waste_categories`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Payments Table
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_method` ENUM('M-Pesa', 'Cash on Collection', 'Bank Transfer') DEFAULT 'M-Pesa',
  `transaction_reference` VARCHAR(100) NOT NULL,
  `payment_status` ENUM('Pending', 'Completed', 'Failed') DEFAULT 'Completed',
  `paid_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`request_id`) REFERENCES `collection_requests`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Messages Table
CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `sender_type` ENUM('user', 'admin') NOT NULL,
  `subject` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Notifications Table (Personalized & System Alerts)
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NULL, -- NULL indicates global announcement for all users
  `title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `type` ENUM('reminder', 'status_update', 'payment', 'general') DEFAULT 'general',
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Contact Inquiries Table
CREATE TABLE IF NOT EXISTS `contact_inquiries` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(25) NOT NULL,
  `subject` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('New', 'Responded') DEFAULT 'New',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ===================================================
-- SEED DATA
-- ===================================================

-- Default Users:
-- Admin: admin@thikawaste.co.ke / Password: admin123
-- Resident: john@gmail.com / Password: user123
-- Hashes below are standard bcrypt for 'admin123' and 'user123'
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `estate`, `address`, `role`, `password`, `status`) VALUES
(1, 'Thika Waste Admin', 'admin@thikawaste.co.ke', '+254712345678', 'Thika Town', 'Municipal Council Building, Commercial Street, Thika', 'admin', '$2y$10$wE0v7H.9tYh7E5Wf9p71puklFvh2w0d2cM3PfxhQ0nIcmm3Xl0d9a', 'active'),
(2, 'John Kamau', 'john@gmail.com', '+254722123456', 'Section 9', 'House 42, Mama Ngina Drive, Section 9, Thika', 'user', '$2y$10$zE5n1tWpU7f7E5Wf9p71puklFvh2w0d2cM3PfxhQ0nIcmm3Xl0d9a', 'active'),
(3, 'Grace Wanjiku', 'grace@gmail.com', '+254733987654', 'Makongeni', 'Phase 3, Block C, Makongeni, Thika', 'user', '$2y$10$zE5n1tWpU7f7E5Wf9p71puklFvh2w0d2cM3PfxhQ0nIcmm3Xl0d9a', 'active');

-- Waste Categories
INSERT INTO `waste_categories` (`id`, `name`, `description`, `unit`, `base_price`, `icon`, `status`) VALUES
(1, 'General Household Waste', 'Daily kitchen refuse, food scraps, non-recyclable domestic waste, and general sweepings.', 'Per 50kg Bag', 150.00, 'fa-trash-alt', 'active'),
(2, 'Recyclables (Plastics, Cans, Paper)', 'Sorted plastics, aluminum beverage cans, cardboard boxes, newspapers, and packaging.', 'Per 50kg Bag', 100.00, 'fa-recycle', 'active'),
(3, 'Commercial & Market Waste', 'High-volume refuse from retail stores, restaurants, groceries, and supermarkets in Thika.', 'Per 240L Wheelie Bin', 450.00, 'fa-store', 'active'),
(4, 'Garden & Yard Trimmings', 'Tree branches, grass clippings, weeds, pruned shrubs, and organic landscaping foliage.', 'Per Pickup / Load', 350.00, 'fa-leaf', 'active'),
(5, 'Electronic & E-Waste', 'Old computers, broken televisions, cables, microwaves, printers, and small home appliances.', 'Per Item/Unit', 400.00, 'fa-laptop', 'active'),
(6, 'Construction & Heavy Debris', 'Renovation leftovers, broken tiles, masonry, drywall, timber cut-offs, and rubble.', 'Per Truck Half-Load', 2500.00, 'fa-truck-loading', 'active');

-- Sample Collection Requests
INSERT INTO `collection_requests` (`id`, `user_id`, `category_id`, `quantity`, `unit_price`, `total_amount`, `pickup_date`, `pickup_time_slot`, `pickup_address`, `estate_zone`, `notes`, `status`, `payment_status`) VALUES
(1, 2, 1, 3, 150.00, 450.00, CURDATE() + INTERVAL 1 DAY, 'Morning (8AM - 11AM)', 'House 42, Mama Ngina Drive, Section 9, Thika', 'Section 9', '3 green bags left near the front gate driveway.', 'Pending', 'Paid'),
(2, 2, 2, 2, 100.00, 200.00, CURDATE() - INTERVAL 2 DAY, 'Afternoon (2PM - 5PM)', 'House 42, Mama Ngina Drive, Section 9, Thika', 'Section 9', 'Recyclables in blue marked sacks.', 'Completed', 'Paid'),
(3, 3, 3, 1, 450.00, 450.00, CURDATE(), 'Morning (8AM - 11AM)', 'Phase 3, Block C, Makongeni, Thika', 'Makongeni', 'Shop entrance behind the main grocery stall.', 'In Progress', 'Unpaid'),
(4, 2, 4, 1, 350.00, 350.00, CURDATE() + INTERVAL 3 DAY, 'Midday (11AM - 2PM)', 'House 42, Mama Ngina Drive, Section 9, Thika', 'Section 9', 'Hedge clippings bundled together.', 'Approved', 'Pending Verification');

-- Sample Payments
INSERT INTO `payments` (`id`, `request_id`, `user_id`, `amount`, `payment_method`, `transaction_reference`, `payment_status`, `paid_at`) VALUES
(1, 1, 2, 450.00, 'M-Pesa', 'QKD982KXM1', 'Completed', NOW() - INTERVAL 1 HOUR),
(2, 2, 2, 200.00, 'M-Pesa', 'QK7192LKJ0', 'Completed', NOW() - INTERVAL 2 DAY);

-- Sample Personalized Notifications & Reminders
INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, 2, 'Pickup Scheduled for Tomorrow', 'Hello John, your General Household Waste collection is scheduled for tomorrow between 8:00 AM - 11:00 AM.', 'reminder', 0, NOW() - INTERVAL 2 HOUR),
(2, 2, 'Payment Received Successfully', 'We received KES 450.00 via M-Pesa (Ref: QKD982KXM1) for Request #1. Thank you!', 'payment', 1, NOW() - INTERVAL 1 HOUR),
(3, 3, 'Urgent: Payment Reminder', 'Hello Grace, your collection for Makongeni today is In Progress. Please complete the pending fee of KES 450.', 'reminder', 0, NOW() - INTERVAL 30 MINUTE),
(4, NULL, 'Thika Public Clean-Up Campaign', 'Join the municipal team this Saturday for the Chania River preservation clean-up.', 'general', 0, NOW() - INTERVAL 1 DAY);

-- Sample Support Messages
INSERT INTO `messages` (`id`, `user_id`, `sender_type`, `subject`, `message`, `is_read`, `created_at`) VALUES
(1, 2, 'user', 'Request for special bin in Section 9', 'Hello Admin, can you provide a heavy-duty 240L wheelie bin for bi-weekly collection?', 1, NOW() - INTERVAL 2 DAY),
(2, 2, 'admin', 'RE: Request for special bin in Section 9', 'Hello John, yes we can deliver a branded 240L wheelie bin on your next scheduled pickup at no extra deposit.', 0, NOW() - INTERVAL 1 DAY);

-- Sample Contact Inquiry
INSERT INTO `contact_inquiries` (`id`, `name`, `email`, `phone`, `subject`, `message`, `status`) VALUES
(1, 'Peter Nderitu', 'peter@business.co.ke', '+254700112233', 'Commercial contract for bakery in Thika Town', 'We generate daily organic flour waste and packaging cartons. Kindly provide corporate quotation.', 'New');
