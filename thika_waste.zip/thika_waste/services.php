<?php
// services.php - Waste Services in Thika
define('PAGE_TITLE', 'Our Services & Pricing | Thika Waste Management');
require_once __DIR__ . '/config/auth.php';

// Fetch categories from DB
try {
    $stmt = $pdo->query("SELECT * FROM waste_categories WHERE status = 'active' ORDER BY base_price ASC");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {
    $categories = [];
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<div style="background:var(--dark); color:var(--white); padding:3.5rem 0;">
    <div class="container text-center">
        <h1 style="color:var(--white); font-size:2.5rem;">Garbage Collection & Environmental Services</h1>
        <p style="color:var(--slate-400); max-width:650px; margin:0 auto;">
            Tailored, compliant, and cost-effective waste management solutions for residents, commercial properties, and institutions in Thika.
        </p>
    </div>
</div>

<main class="main-content">
    <div class="container">
        <!-- Service Breakdown -->
        <div style="margin-bottom:3rem;">
            <h2>Available Collection Services & Rates</h2>
            <p>Select any category below to schedule your pickup immediately.</p>
        </div>

        <div class="features-grid" style="grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));">
            <?php foreach ($categories as $cat): ?>
                <div class="card card-hover" style="display:flex; flex-direction:column; justify-content:space-between; border-top: 4px solid var(--primary);">
                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:1.25rem;">
                            <div class="feature-icon-wrapper" style="margin-bottom:0;">
                                <i class="fa <?= htmlspecialchars($cat['icon'] ?: 'fa-trash') ?>"></i>
                            </div>
                            <span class="badge badge-primary"><?= htmlspecialchars($cat['unit']) ?></span>
                        </div>

                        <h3 style="margin-bottom:0.5rem;"><?= htmlspecialchars($cat['name']) ?></h3>
                        <p style="font-size:0.925rem; color:var(--slate-600); margin-bottom:1.5rem;">
                            <?= htmlspecialchars($cat['description']) ?>
                        </p>

                        <div style="background:var(--slate-50); border:1px solid var(--slate-200); border-radius:var(--radius-md); padding:1rem; margin-bottom:1.25rem;">
                            <ul style="list-style:none; font-size:0.875rem; color:var(--slate-600);">
                                <li style="margin-bottom:0.4rem;"><i class="fa fa-check" style="color:var(--primary); margin-right:8px;"></i> Standard curbside or door-to-door</li>
                                <li style="margin-bottom:0.4rem;"><i class="fa fa-check" style="color:var(--primary); margin-right:8px;"></i> Eco-certified Kiambu County dumping</li>
                                <li><i class="fa fa-check" style="color:var(--primary); margin-right:8px;"></i> Instant M-Pesa receipt verification</li>
                            </ul>
                        </div>
                    </div>

                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:1.25rem;">
                            <span style="font-size:0.85rem; color:var(--slate-400);">Fixed Rate</span>
                            <div>
                                <span style="font-size:1.6rem; font-weight:800; color:var(--primary);"><?= formatKES($cat['base_price']) ?></span>
                                <small style="color:var(--slate-400); font-weight:500;">/ <?= htmlspecialchars($cat['unit']) ?></small>
                            </div>
                        </div>

                        <a href="<?= $baseUrl ?>/user/request_collection.php?category_id=<?= $cat['id'] ?>" class="btn btn-primary btn-block">
                            <i class="fa fa-calendar-alt"></i> Request This Pickup
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Frequency Plans -->
        <div style="margin-top:4rem;">
            <div style="text-align:center; max-width:650px; margin:0 auto 2.5rem;">
                <h2>Pickup Frequency Options</h2>
                <p>Choose between scheduled recurring intervals or on-demand pickups whenever your bins fill up.</p>
            </div>

            <div class="features-grid">
                <div class="card text-center" style="padding:2rem;">
                    <div class="stat-icon stat-icon-primary" style="margin:0 auto 1rem;"><i class="fa fa-calendar-day"></i></div>
                    <h3>Weekly Residential</h3>
                    <p>Designed for households and apartment complexes in Section 9, Makongeni, and Ngoingwa. Weekly pickups with dedicated colored garbage sacks.</p>
                </div>

                <div class="card text-center" style="padding:2rem;">
                    <div class="stat-icon stat-icon-warning" style="margin:0 auto 1rem;"><i class="fa fa-calendar-week"></i></div>
                    <h3>Bi-Weekly Commercial</h3>
                    <p>Twice-a-week pickups for supermarkets, hotels, cafes, and bakeries in Thika CBD with heavy-duty 240L wheelie bins.</p>
                </div>

                <div class="card text-center" style="padding:2rem;">
                    <div class="stat-icon stat-icon-success" style="margin:0 auto 1rem;"><i class="fa fa-bolt"></i></div>
                    <h3>On-Demand & Emergency</h3>
                    <p>Moving out, holding a large wedding or family gathering, or post-construction clutter? Book same-day or next-day truck dispatch.</p>
                </div>
            </div>
        </div>

        <!-- Call to Action Banner -->
        <div class="card" style="background:var(--primary); color:var(--white); margin-top:3rem; padding:2.5rem; text-align:center;">
            <h2 style="color:var(--white); font-size:1.85rem; margin-bottom:0.75rem;">Ready for a Cleaner Thika?</h2>
            <p style="color:#d1fae5; max-width:600px; margin:0 auto 1.5rem;">
                Create a resident profile in 30 seconds or log into your account to book your first scheduled collection.
            </p>
            <div style="display:flex; justify-content:center; gap:1rem; flex-wrap:wrap;">
                <a href="<?= $baseUrl ?>/register.php" class="btn btn-secondary btn-lg" style="background:var(--white); color:var(--dark);">
                    Register Free Account
                </a>
                <a href="<?= $baseUrl ?>/user/request_collection.php" class="btn btn-outline-primary btn-lg" style="border-color:var(--white); color:var(--white);">
                    Schedule Collection Now
                </a>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
