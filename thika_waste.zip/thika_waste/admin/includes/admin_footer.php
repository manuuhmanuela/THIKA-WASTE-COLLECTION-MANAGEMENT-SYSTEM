<?php
// admin/includes/admin_footer.php
$baseUrl = getBaseUrl();
?>
        </div> <!-- End .admin-content -->
    </div> <!-- End .admin-main -->
</div> <!-- End .admin-wrapper -->

<!-- Scripts -->
<script src="<?= $baseUrl ?>/assets/js/main.js"></script>
</body>
</html>
