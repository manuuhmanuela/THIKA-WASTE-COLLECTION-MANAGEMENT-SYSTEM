<?php
// admin/includes/admin_header.php - Strict Admin Layout & Topbar
require_once __DIR__ . '/bootstrap.php';

$currentScript = basename($_SERVER['SCRIPT_NAME']);
$flash = getFlash();

// Pending collections badge
$pendingCount = getPendingCollectionsCount($pdo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= defined('PAGE_TITLE') ? htmlspecialchars(PAGE_TITLE) : 'Admin Console | Thika Waste Management' ?></title>
    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
</head>
<body>

<div class="admin-wrapper">
    <!-- Admin Sidebar -->
    <?php require_once __DIR__ . '/admin_sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="admin-main">
        <header class="admin-topbar">
            <div style="display:flex; align-items:center; gap:1rem;">
                <button class="mobile-toggle" onclick="document.querySelector('.admin-sidebar').classList.toggle('active')" style="display:none;">
                    <i class="fa fa-bars"></i>
                </button>
                <div style="font-weight:700; font-size:1.1rem; color:var(--dark);">
                    Thika Waste Operations Control
                </div>
            </div>

            <div style="display:flex; align-items:center; gap:1.25rem;">
                <a href="<?= $baseUrl ?>/index.php" target="_blank" class="btn btn-sm btn-secondary" title="View Public Website">
                    <i class="fa fa-external-link-alt"></i> View Website
                </a>

                <div style="display:flex; align-items:center; gap:0.6rem;">
                    <div class="admin-avatar">
                        <?= strtoupper(substr($adminUser['name'], 0, 1)) ?>
                    </div>
                    <div>
                        <div style="font-size:0.875rem; font-weight:700; color:var(--dark);"><?= htmlspecialchars($adminUser['name']) ?></div>
                        <div style="font-size:0.75rem; color:var(--primary); font-weight:600;"><i class="fa fa-shield-alt"></i> System Administrator</div>
                    </div>
                </div>

                <a href="<?= $baseUrl ?>/logout.php" class="btn btn-sm btn-outline-primary" style="color:var(--danger); border-color:var(--slate-200);" title="Logout">
                    <i class="fa fa-sign-out-alt"></i>
                </a>
            </div>
        </header>

        <?php if ($flash): ?>
        <div style="padding: 1rem 2rem 0;">
            <div class="alert alert-<?= htmlspecialchars($flash['type']) ?>">
                <span><?= htmlspecialchars($flash['message']) ?></span>
                <button class="alert-close">&times;</button>
            </div>
        </div>
        <?php endif; ?>

        <div class="admin-content">
