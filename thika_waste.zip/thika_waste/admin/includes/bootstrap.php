<?php
// admin/includes/bootstrap.php - Clean backend bootstrapping without HTML output
require_once __DIR__ . '/../../config/auth.php';
requireAdmin('/login.php');

$adminUser = currentUser();
$baseUrl = getBaseUrl();
