<?php
// admin/includes/admin_sidebar.php - Strictly Admin Navigation Links
$currentScript = basename($_SERVER['SCRIPT_NAME']);
$baseUrl = getBaseUrl();
?>
<aside class="admin-sidebar">
    <div class="admin-brand">
        <div class="brand-icon" style="width:36px; height:36px; font-size:1.1rem;">
            <i class="fa fa-recycle"></i>
        </div>
        <span>Thika<strong style="color:var(--primary);">Clean</strong> <span style="font-size:0.7rem; background:#047857; color:#fff; padding:2px 6px; border-radius:4px; font-weight:600;">ADMIN</span></span>
    </div>

    <ul class="admin-menu">
        <li class="admin-menu-item <?= ($currentScript === 'index.php') ? 'active' : '' ?>">
            <a href="<?= $baseUrl ?>/admin/index.php" class="admin-menu-link">
                <i class="fa fa-tachometer-alt"></i>
                <span>Admin Dashboard</span>
            </a>
        </li>

        <li class="admin-menu-item <?= ($currentScript === 'collections.php') ? 'active' : '' ?>">
            <a href="<?= $baseUrl ?>/admin/collections.php" class="admin-menu-link">
                <i class="fa fa-truck-pickup"></i>
                <span>Collections</span>
                <?php if (isset($pendingCount) && $pendingCount > 0): ?>
                    <span class="admin-menu-badge"><?= $pendingCount ?></span>
                <?php endif; ?>
            </a>
        </li>

        <li class="admin-menu-item <?= ($currentScript === 'users.php') ? 'active' : '' ?>">
            <a href="<?= $baseUrl ?>/admin/users.php" class="admin-menu-link">
                <i class="fa fa-users"></i>
                <span>Registered Residents</span>
            </a>
        </li>

        <li class="admin-menu-item <?= ($currentScript === 'categories.php') ? 'active' : '' ?>">
            <a href="<?= $baseUrl ?>/admin/categories.php" class="admin-menu-link">
                <i class="fa fa-tags"></i>
                <span>Waste Categories</span>
            </a>
        </li>

        <li class="admin-menu-item <?= ($currentScript === 'payments.php') ? 'active' : '' ?>">
            <a href="<?= $baseUrl ?>/admin/payments.php" class="admin-menu-link">
                <i class="fa fa-money-bill-wave"></i>
                <span>Payments & Revenue</span>
            </a>
        </li>

        <li class="admin-menu-item <?= ($currentScript === 'reminders.php') ? 'active' : '' ?>">
            <a href="<?= $baseUrl ?>/admin/reminders.php" class="admin-menu-link">
                <i class="fa fa-paper-plane"></i>
                <span>Send Reminders</span>
            </a>
        </li>

        <li class="admin-menu-item <?= ($currentScript === 'messages.php') ? 'active' : '' ?>">
            <a href="<?= $baseUrl ?>/admin/messages.php" class="admin-menu-link">
                <i class="fa fa-envelope-open-text"></i>
                <span>Support Inquiries</span>
            </a>
        </li>

        <li class="admin-menu-item <?= ($currentScript === 'reports.php') ? 'active' : '' ?>">
            <a href="<?= $baseUrl ?>/admin/reports.php" class="admin-menu-link">
                <i class="fa fa-chart-bar"></i>
                <span>Reports & Analytics</span>
            </a>
        </li>
    </ul>

    <div class="admin-user-profile">
        <div class="admin-avatar">
            <?= strtoupper(substr($adminUser['name'], 0, 1)) ?>
        </div>
        <div style="flex:1; overflow:hidden;">
            <div style="font-size:0.85rem; font-weight:700; color:var(--white); white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">
                <?= htmlspecialchars($adminUser['name']) ?>
            </div>
            <div style="font-size:0.75rem; color:var(--slate-400);">
                <?= htmlspecialchars($adminUser['email']) ?>
            </div>
        </div>
        <a href="<?= $baseUrl ?>/logout.php" style="color:var(--slate-400);" title="Logout">
            <i class="fa fa-power-off"></i>
        </a>
    </div>
</aside>
