<?php
// admin/collections.php - Manage All Garbage Collection Requests
require_once __DIR__ . '/includes/bootstrap.php';

// Handle Status Change POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $reqId = (int)($_POST['request_id'] ?? 0);
    $newStatus = trim($_POST['status'] ?? '');
    $adminNote = trim($_POST['status_note'] ?? '');

    $validStatuses = ['Pending', 'Approved', 'In Progress', 'Completed', 'Cancelled'];
    if ($reqId > 0 && in_array($newStatus, $validStatuses)) {
        try {
            // Get user_id for notification
            $stmt = $pdo->prepare("SELECT user_id, estate_zone FROM collection_requests WHERE id = ?");
            $stmt->execute([$reqId]);
            $req = $stmt->fetch();

            if ($req) {
                // Update collection status
                $upd = $pdo->prepare("UPDATE collection_requests SET status = ?, updated_at = NOW() WHERE id = ?");
                $upd->execute([$newStatus, $reqId]);

                // Create alert notification for this specific user
                $notifTitle = "Pickup Request #{$reqId} Status Updated: {$newStatus}";
                $notifMsg = "Your collection request #{$reqId} in {$req['estate_zone']} has been marked as '{$newStatus}'.";
                if (!empty($adminNote)) {
                    $notifMsg .= " Operational Note: " . $adminNote;
                }

                $notifStmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'status_update')");
                $notifStmt->execute([$req['user_id'], $notifTitle, $notifMsg]);

                setFlash('success', "Request #{$reqId} status successfully updated to '{$newStatus}' and resident notified.");
            }
        } catch (Exception $e) {
            setFlash('danger', 'Error updating status: ' . $e->getMessage());
        }
    }
    header('Location: ' . $baseUrl . '/admin/collections.php');
    exit;
}

define('PAGE_TITLE', 'Manage Collections | Thika Waste Management');
require_once __DIR__ . '/includes/admin_header.php';

// Filters
$filterStatus = $_GET['status'] ?? '';
$filterZone = $_GET['zone'] ?? '';
$filterCategory = (int)($_GET['category_id'] ?? 0);
$search = trim($_GET['search'] ?? '');

// Build Query
$sql = "
    SELECT cr.*, u.name AS user_name, u.phone AS user_phone, u.email AS user_email,
           wc.name AS category_name, wc.unit AS category_unit
    FROM collection_requests cr
    JOIN users u ON cr.user_id = u.id
    JOIN waste_categories wc ON cr.category_id = wc.id
    WHERE 1=1
";
$params = [];

if (!empty($filterStatus)) {
    $sql .= " AND cr.status = ?";
    $params[] = $filterStatus;
}
if (!empty($filterZone)) {
    $sql .= " AND cr.estate_zone = ?";
    $params[] = $filterZone;
}
if ($filterCategory > 0) {
    $sql .= " AND cr.category_id = ?";
    $params[] = $filterCategory;
}
if (!empty($search)) {
    $sql .= " AND (u.name LIKE ? OR u.phone LIKE ? OR cr.pickup_address LIKE ? OR cr.id = ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = $search;
}

$sql .= " ORDER BY cr.id DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $collections = $stmt->fetchAll();

    // Fetch categories for filter dropdown
    $categories = $pdo->query("SELECT id, name FROM waste_categories ORDER BY name ASC")->fetchAll();
} catch (Exception $e) {
    die("Error fetching collections: " . $e->getMessage());
}
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
    <div>
        <h2><i class="fa fa-truck-pickup" style="color:var(--primary); margin-right:8px;"></i> All Garbage Collections</h2>
        <p style="margin:0;">Inspect, schedule, dispatch, and update statuses of municipal waste collection orders.</p>
    </div>
    <div>
        <a href="<?= $baseUrl ?>/admin/reports.php" class="btn btn-secondary">
            <i class="fa fa-print"></i> Print Collection Manifest
        </a>
    </div>
</div>

<!-- Filter Bar -->
<div class="card" style="padding:1.25rem; margin-bottom:1.5rem;">
    <form action="<?= $baseUrl ?>/admin/collections.php" method="GET" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)) 100px; gap:1rem; align-items:flex-end;">
        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Status</label>
            <select name="status" class="form-control">
                <option value="">All Statuses</option>
                <?php foreach (['Pending', 'Approved', 'In Progress', 'Completed', 'Cancelled'] as $st): ?>
                    <option value="<?= $st ?>" <?= ($filterStatus === $st) ? 'selected' : '' ?>><?= $st ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Thika Zone</label>
            <select name="zone" class="form-control">
                <option value="">All Zones</option>
                <?php foreach (getThikaZones() as $zn): ?>
                    <option value="<?= htmlspecialchars($zn) ?>" <?= ($filterZone === $zn) ? 'selected' : '' ?>><?= htmlspecialchars($zn) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Waste Category</label>
            <select name="category_id" class="form-control">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= ($filterCategory === (int)$cat['id']) ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Search</label>
            <input type="text" name="search" class="form-control" placeholder="Resident or Address..." value="<?= htmlspecialchars($search) ?>">
        </div>

        <div>
            <button type="submit" class="btn btn-primary btn-block" style="padding:0.65rem 0.5rem;">
                <i class="fa fa-filter"></i> Filter
            </button>
        </div>
    </form>
</div>

<!-- Collections Table -->
<div class="card">
    <div class="card-header">
        <h3 style="margin:0;">Collection Records (<?= count($collections) ?> Found)</h3>
    </div>

    <?php if (empty($collections)): ?>
        <div style="text-align:center; padding:3rem 1rem; color:var(--slate-400);">
            <i class="fa fa-search" style="font-size:2.5rem; margin-bottom:1rem;"></i>
            <h4>No Collection Orders Found</h4>
            <p>Try resetting the search filters above.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Resident / Contact</th>
                        <th>Waste Details</th>
                        <th>Thika Zone & Address</th>
                        <th>Pickup Schedule</th>
                        <th>Amount</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($collections as $c): ?>
                        <tr>
                            <td><strong>#<?= $c['id'] ?></strong></td>
                            <td>
                                <strong><?= htmlspecialchars($c['user_name']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--slate-400);"><i class="fa fa-phone"></i> <?= htmlspecialchars($c['user_phone']) ?></div>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($c['category_name']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--slate-400);"><?= $c['quantity'] ?> <?= htmlspecialchars($c['category_unit']) ?></div>
                            </td>
                            <td>
                                <strong><i class="fa fa-map-marker-alt" style="color:var(--primary);"></i> <?= htmlspecialchars($c['estate_zone']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--slate-400); max-width:180px; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="<?= htmlspecialchars($c['pickup_address']) ?>">
                                    <?= htmlspecialchars($c['pickup_address']) ?>
                                </div>
                            </td>
                            <td>
                                <div><i class="fa fa-calendar-alt"></i> <?= date('d M Y', strtotime($c['pickup_date'])) ?></div>
                                <div style="font-size:0.75rem; color:var(--slate-400);"><?= htmlspecialchars($c['pickup_time_slot']) ?></div>
                            </td>
                            <td>
                                <strong><?= formatKES($c['total_amount']) ?></strong>
                            </td>
                            <td><?= statusBadge($c['payment_status']) ?></td>
                            <td><?= statusBadge($c['status']) ?></td>
                            <td>
                                <div style="display:flex; gap:0.4rem;">
                                    <button class="btn btn-sm btn-primary" onclick="openStatusModal('<?= $c['id'] ?>', '<?= $c['status'] ?>', '<?= htmlspecialchars(addslashes($c['notes'] ?? '')) ?>')" title="Change Status">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <a href="<?= $baseUrl ?>/admin/reminders.php?user_id=<?= $c['user_id'] ?>&ref=<?= $c['id'] ?>" class="btn btn-sm btn-secondary" title="Send Reminder to Resident">
                                        <i class="fa fa-bell"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Modal for Changing Status -->
<div class="modal-overlay" id="statusChangeModal">
    <div class="modal-box">
        <div class="modal-header">
            <h4 style="margin:0;"><i class="fa fa-sliders-h" style="color:var(--primary);"></i> Update Collection Request Status</h4>
            <button class="alert-close" onclick="closeModal('statusChangeModal')">&times;</button>
        </div>
        <form action="<?= $baseUrl ?>/admin/collections.php" method="POST">
            <input type="hidden" name="action" value="update_status">
            <input type="hidden" name="request_id" id="modal_request_id" value="">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">New Status</label>
                    <select name="status" id="modal_status_select" class="form-control" required>
                        <option value="Pending">Pending (Awaiting Confirmation)</option>
                        <option value="Approved">Approved (Scheduled for Pickup)</option>
                        <option value="In Progress">In Progress (Driver Dispatched)</option>
                        <option value="Completed">Completed (Waste Collected & Cleared)</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Operational Note / Message to Resident</label>
                    <textarea name="status_note" id="modal_notes" class="form-control" rows="3" placeholder="e.g. Truck registration KDA 123X dispatched. Driver Samuel en route to Section 9."></textarea>
                    <small class="form-help">This note will be automatically sent as a notification to the resident.</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('statusChangeModal')">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Save & Notify Resident</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
