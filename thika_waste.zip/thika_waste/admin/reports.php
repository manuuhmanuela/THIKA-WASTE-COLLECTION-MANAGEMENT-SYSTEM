<?php
// admin/reports.php - Operational & Financial Reporting Module
require_once __DIR__ . '/includes/bootstrap.php';

// Date filters
$dateFrom = $_GET['date_from'] ?? date('Y-m-01'); // First day of current month
$dateTo = $_GET['date_to'] ?? date('Y-m-d');     // Today
$zoneFilter = $_GET['zone'] ?? '';
$catFilter = (int)($_GET['category_id'] ?? 0);
$statusFilter = $_GET['status'] ?? '';
$isExport = isset($_GET['export']) && $_GET['export'] === 'csv';

// Base SQL
$sql = "
    SELECT cr.*, u.name AS user_name, u.phone AS user_phone, u.email AS user_email,
           wc.name AS category_name, wc.unit AS category_unit
    FROM collection_requests cr
    JOIN users u ON cr.user_id = u.id
    JOIN waste_categories wc ON cr.category_id = wc.id
    WHERE 1=1
";
$params = [];

if (!empty($dateFrom)) {
    $sql .= " AND DATE(cr.pickup_date) >= ?";
    $params[] = $dateFrom;
}
if (!empty($dateTo)) {
    $sql .= " AND DATE(cr.pickup_date) <= ?";
    $params[] = $dateTo;
}
if (!empty($zoneFilter)) {
    $sql .= " AND cr.estate_zone = ?";
    $params[] = $zoneFilter;
}
if ($catFilter > 0) {
    $sql .= " AND cr.category_id = ?";
    $params[] = $catFilter;
}
if (!empty($statusFilter)) {
    $sql .= " AND cr.status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY cr.pickup_date DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $reportData = $stmt->fetchAll();

    // Export to CSV if requested
    if ($isExport) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=thika_waste_report_' . date('Ymd_His') . '.csv');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Request ID', 'Resident Name', 'Phone', 'Thika Zone', 'Address', 'Category', 'Quantity', 'Amount (KES)', 'Pickup Date', 'Time Slot', 'Payment Status', 'Collection Status']);

        foreach ($reportData as $row) {
            fputcsv($output, [
                $row['id'],
                $row['user_name'],
                $row['user_phone'],
                $row['estate_zone'],
                $row['pickup_address'],
                $row['category_name'],
                $row['quantity'] . ' ' . $row['category_unit'],
                $row['total_amount'],
                $row['pickup_date'],
                $row['pickup_time_slot'],
                $row['payment_status'],
                $row['status']
            ]);
        }
        fclose($output);
        exit;
    }

    // Aggregations
    $totalRequests = count($reportData);
    $totalRevenue = 0;
    $completedCount = 0;
    $paidCount = 0;
    $categorySummary = [];
    $zoneSummary = [];

    foreach ($reportData as $row) {
        $amt = (float)$row['total_amount'];
        $totalRevenue += $amt;

        if ($row['status'] === 'Completed') $completedCount++;
        if ($row['payment_status'] === 'Paid') $paidCount++;

        // Cat summary
        $cName = $row['category_name'];
        if (!isset($categorySummary[$cName])) {
            $categorySummary[$cName] = ['count' => 0, 'revenue' => 0];
        }
        $categorySummary[$cName]['count']++;
        $categorySummary[$cName]['revenue'] += $amt;

        // Zone summary
        $zName = $row['estate_zone'];
        if (!isset($zoneSummary[$zName])) {
            $zoneSummary[$zName] = ['count' => 0, 'revenue' => 0];
        }
        $zoneSummary[$zName]['count']++;
        $zoneSummary[$zName]['revenue'] += $amt;
    }

    $avgOrderValue = $totalRequests > 0 ? ($totalRevenue / $totalRequests) : 0;
    $completionRate = $totalRequests > 0 ? round(($completedCount / $totalRequests) * 100, 1) : 0;

    // Categories for filter
    $categories = $pdo->query("SELECT id, name FROM waste_categories ORDER BY name ASC")->fetchAll();

    die("Error compiling report: " . $e->getMessage());
}

define('PAGE_TITLE', 'Reports & Analytics | Thika Waste Management');
require_once __DIR__ . '/includes/admin_header.php';
?>

<!-- Print-Only Letterhead Header -->
<div style="display:none;" class="print-only">
    <div style="text-align:center; border-bottom:2px solid #059669; padding-bottom:1rem; margin-bottom:1.5rem;">
        <h1 style="margin:0; color:#059669;">Thika Clean Waste Management</h1>
        <p style="margin:0; font-size:10pt;">Kiambu County Municipal Solid Waste Directorate &bull; Official Operations Report</p>
        <div style="font-size:9pt; color:#64748b; margin-top:4px;">
            Reporting Period: <strong><?= date('d M Y', strtotime($dateFrom)) ?></strong> to <strong><?= date('d M Y', strtotime($dateTo)) ?></strong> &bull; Generated on: <?= date('d M Y, H:i') ?>
        </div>
    </div>
</div>

<div class="no-print" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
    <div>
        <h2><i class="fa fa-chart-bar" style="color:var(--primary); margin-right:8px;"></i> Waste Reports & Municipal Analytics</h2>
        <p style="margin:0;">Generate custom operational summaries, revenue reports, and export official CSV datasets.</p>
    </div>
    <div style="display:flex; gap:0.75rem;">
        <button class="btn btn-secondary" onclick="window.print()">
            <i class="fa fa-print"></i> Print Report / PDF
        </button>
        <?php 
            $exportParams = $_GET;
            $exportParams['export'] = 'csv';
            $exportUrl = $baseUrl . '/admin/reports.php?' . http_build_query($exportParams);
        ?>
        <a href="<?= $exportUrl ?>" class="btn btn-primary">
            <i class="fa fa-file-excel"></i> Export CSV
        </a>
    </div>
</div>

<!-- Filter Box -->
<div class="card no-print" style="padding:1.25rem; margin-bottom:1.5rem;">
    <form action="<?= $baseUrl ?>/admin/reports.php" method="GET" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)) 100px; gap:1rem; align-items:flex-end;">
        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">From Date</label>
            <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($dateFrom) ?>">
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">To Date</label>
            <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($dateTo) ?>">
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Thika Zone</label>
            <select name="zone" class="form-control">
                <option value="">All Zones</option>
                <?php foreach (getThikaZones() as $zn): ?>
                    <option value="<?= htmlspecialchars($zn) ?>" <?= ($zoneFilter === $zn) ? 'selected' : '' ?>><?= htmlspecialchars($zn) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Waste Category</label>
            <select name="category_id" class="form-control">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= ($catFilter === (int)$cat['id']) ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Status</label>
            <select name="status" class="form-control">
                <option value="">All Statuses</option>
                <?php foreach (['Pending', 'Approved', 'In Progress', 'Completed', 'Cancelled'] as $st): ?>
                    <option value="<?= $st ?>" <?= ($statusFilter === $st) ? 'selected' : '' ?>><?= $st ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <button type="submit" class="btn btn-primary btn-block" style="padding:0.65rem 0.5rem;">
                <i class="fa fa-sync-alt"></i> Run
            </button>
        </div>
    </form>
</div>

<!-- Key Performance Metrics -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon stat-icon-primary"><i class="fa fa-truck-pickup"></i></div>
        <div>
            <div class="stat-number"><?= number_format($totalRequests) ?></div>
            <div class="stat-label">Total Pickups in Period</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-success"><i class="fa fa-money-bill-wave"></i></div>
        <div>
            <div class="stat-number"><?= formatKES($totalRevenue) ?></div>
            <div class="stat-label">Period Billing Volume</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-info"><i class="fa fa-calculator"></i></div>
        <div>
            <div class="stat-number"><?= formatKES($avgOrderValue) ?></div>
            <div class="stat-label">Average Order Value</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-warning"><i class="fa fa-percentage"></i></div>
        <div>
            <div class="stat-number"><?= $completionRate ?>%</div>
            <div class="stat-label">Completion Efficiency</div>
        </div>
    </div>
</div>

<!-- Aggregated Summaries -->
<div style="display:grid; grid-template-columns: 1fr 1fr; gap:1.75rem; margin-bottom:2rem;">
    <!-- By Category -->
    <div class="card">
        <div class="card-header">
            <h3 style="margin:0;">Revenue by Waste Category</h3>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Pickups</th>
                        <th>Total Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categorySummary as $cName => $cData): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($cName) ?></strong></td>
                            <td><?= $cData['count'] ?></td>
                            <td><strong style="color:var(--primary);"><?= formatKES($cData['revenue']) ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- By Zone -->
    <div class="card">
        <div class="card-header">
            <h3 style="margin:0;">Top Performing Thika Zones</h3>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Zone / Estate</th>
                        <th>Pickups</th>
                        <th>Total Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($zoneSummary as $zName => $zData): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($zName) ?></strong></td>
                            <td><?= $zData['count'] ?></td>
                            <td><strong style="color:var(--primary);"><?= formatKES($zData['revenue']) ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Detailed Data Table -->
<div class="card">
    <div class="card-header">
        <h3 style="margin:0;">Detailed Manifest Records</h3>
    </div>

    <?php if (empty($reportData)): ?>
        <p style="text-align:center; color:var(--slate-400); padding:2.5rem 0;">No records match your selected filter criteria.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Pickup Date</th>
                        <th>Resident</th>
                        <th>Estate</th>
                        <th>Waste Category</th>
                        <th>Quantity</th>
                        <th>Amount</th>
                        <th>Payment</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reportData as $row): ?>
                        <tr>
                            <td><strong>#<?= $row['id'] ?></strong></td>
                            <td><?= date('d M Y', strtotime($row['pickup_date'])) ?></td>
                            <td>
                                <strong><?= htmlspecialchars($row['user_name']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--slate-400);"><?= htmlspecialchars($row['user_phone']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($row['estate_zone']) ?></td>
                            <td><?= htmlspecialchars($row['category_name']) ?></td>
                            <td><?= $row['quantity'] ?> <?= htmlspecialchars($row['category_unit']) ?></td>
                            <td><strong><?= formatKES($row['total_amount']) ?></strong></td>
                            <td><?= statusBadge($row['payment_status']) ?></td>
                            <td><?= statusBadge($row['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<style>
@media print {
    .print-only { display: block !important; }
}
</style>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
