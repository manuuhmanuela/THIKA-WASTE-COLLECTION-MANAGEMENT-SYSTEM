<?php
// admin/categories.php - Manage Waste Categories & Tariffs

// ============ 1) BOOTSTRAP (no output yet) ============
require_once __DIR__ . '/includes/bootstrap.php';   // defines $pdo, $baseUrl, setFlash()

// ============ 2) POST HANDLER (no output yet) ============
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name        = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $unit        = trim($_POST['unit'] ?? 'Per 50kg Bag');
        $basePrice   = (float)($_POST['base_price'] ?? 150.00);
        $icon        = trim($_POST['icon'] ?? 'fa-trash-alt');

        if (!empty($name) && $basePrice > 0) {
            try {
                $stmt = $pdo->prepare("INSERT INTO waste_categories (name, description, unit, base_price, icon, status) VALUES (?, ?, ?, ?, ?, 'active')");
                $stmt->execute([$name, $description, $unit, $basePrice, $icon]);
                setFlash('success', 'New waste category "' . htmlspecialchars($name) . '" added successfully.');
            } catch (Exception $e) {
                setFlash('danger', 'Error adding category: ' . $e->getMessage());
            }
        } else {
            setFlash('danger', 'Category name and valid price are required.');
        }

    } elseif ($action === 'edit') {
        $catId       = (int)($_POST['category_id'] ?? 0);
        $name        = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $unit        = trim($_POST['unit'] ?? '');
        $basePrice   = (float)($_POST['base_price'] ?? 0);
        $icon        = trim($_POST['icon'] ?? 'fa-trash-alt');
        $status      = trim($_POST['status'] ?? 'active');

        if ($catId > 0 && !empty($name) && $basePrice > 0) {
            try {
                $stmt = $pdo->prepare("UPDATE waste_categories SET name = ?, description = ?, unit = ?, base_price = ?, icon = ?, status = ? WHERE id = ?");
                $stmt->execute([$name, $description, $unit, $basePrice, $icon, $status, $catId]);
                setFlash('success', 'Category #' . $catId . ' updated successfully.');
            } catch (Exception $e) {
                setFlash('danger', 'Error updating category: ' . $e->getMessage());
            }
        }

    } elseif ($action === 'delete') {
        $catId = (int)($_POST['category_id'] ?? 0);
        try {
            $chk = $pdo->prepare("SELECT COUNT(*) FROM collection_requests WHERE category_id = ?");
            $chk->execute([$catId]);
            if ($chk->fetchColumn() > 0) {
                $pdo->prepare("UPDATE waste_categories SET status = 'inactive' WHERE id = ?")->execute([$catId]);
                setFlash('info', 'Category #' . $catId . ' has existing collection orders and was set to Inactive instead of hard deleting.');
            } else {
                $pdo->prepare("DELETE FROM waste_categories WHERE id = ?")->execute([$catId]);
                setFlash('success', 'Category #' . $catId . ' deleted successfully.');
            }
        } catch (Exception $e) {
            setFlash('danger', 'Error deleting category: ' . $e->getMessage());
        }
    }

    // Redirect BEFORE any output — this is the fix for the header warning
    header('Location: ' . $baseUrl . '/admin/categories.php');
    exit;
}

// ============ 3) NOW output the header ============
define('PAGE_TITLE', 'Waste Categories & Tariffs | Thika Waste Management');
require_once __DIR__ . '/includes/admin_header.php';

// ============ 4) Fetch data for the table ============
try {
    $stmt = $pdo->query("
        SELECT wc.*, COUNT(cr.id) AS usage_count
        FROM waste_categories wc
        LEFT JOIN collection_requests cr ON wc.id = cr.category_id
        GROUP BY wc.id
        ORDER BY wc.id ASC
    ");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {
    $categories = [];
}
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
    <div>
        <h2><i class="fa fa-tags" style="color:var(--primary); margin-right:8px;"></i> Waste Categories & Municipal Tariffs</h2>
        <p style="margin:0;">Configure garbage types, volume billing units, and standardized rates for Thika residents.</p>
    </div>
    <button class="btn btn-primary" onclick="openModal('addCategoryModal')">
        <i class="fa fa-plus-circle"></i> Add New Category
    </button>
</div>

<!-- Categories Table -->
<div class="card">
    <div class="card-header">
        <h3 style="margin:0;">Active Tariff Categories</h3>
    </div>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Icon</th>
                    <th>Category Name</th>
                    <th>Billing Unit</th>
                    <th>Base Rate</th>
                    <th>Description</th>
                    <th>Orders Using This</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($categories)): ?>
                    <tr>
                        <td colspan="8" style="text-align:center; padding:2rem; color:var(--slate-400);">
                            No categories yet. Click <b>Add New Category</b> to create your first one.
                        </td>
                    </tr>
                <?php else: foreach ($categories as $cat): ?>
                    <tr>
                        <td>
                            <div style="width:38px; height:38px; border-radius:var(--radius-md); background:var(--primary-light); color:var(--primary); display:flex; align-items:center; justify-content:center; font-size:1.1rem;">
                                <i class="fa <?= htmlspecialchars($cat['icon'] ?: 'fa-trash') ?>"></i>
                            </div>
                        </td>
                        <td>
                            <strong><?= htmlspecialchars($cat['name']) ?></strong>
                        </td>
                        <td>
                            <span class="badge badge-info"><?= htmlspecialchars($cat['unit']) ?></span>
                        </td>
                        <td>
                            <strong style="color:var(--primary); font-size:1.05rem;"><?= formatKES($cat['base_price']) ?></strong>
                        </td>
                        <td>
                            <div style="font-size:0.85rem; color:var(--slate-600); max-width:260px;">
                                <?= htmlspecialchars($cat['description']) ?>
                            </div>
                        </td>
                        <td>
                            <span class="badge badge-secondary"><?= $cat['usage_count'] ?> Pickups</span>
                        </td>
                        <td>
                            <?php if ($cat['status'] === 'active'): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div style="display:flex; gap:0.4rem;">
                                <button class="btn btn-sm btn-secondary" onclick="openEditModal(<?= htmlspecialchars(json_encode($cat)) ?>)">
                                    <i class="fa fa-edit"></i> Edit
                                </button>
                                <form action="<?= $baseUrl ?>/admin/categories.php" method="POST" onsubmit="return confirm('Remove category <?= htmlspecialchars($cat['name']) ?>?');" style="display:inline;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="category_id" value="<?= $cat['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal: Add Category -->
<div class="modal-overlay" id="addCategoryModal">
    <div class="modal-box">
        <div class="modal-header">
            <h4 style="margin:0;"><i class="fa fa-plus-circle" style="color:var(--primary);"></i> Add Waste Category</h4>
            <button class="alert-close" onclick="closeModal('addCategoryModal')">&times;</button>
        </div>
        <form action="<?= $baseUrl ?>/admin/categories.php" method="POST">
            <input type="hidden" name="action" value="add">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Category Name <span style="color:var(--danger);">*</span></label>
                    <input type="text" name="name" class="form-control" placeholder="e.g. Garden & Yard Waste" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Billing Unit <span style="color:var(--danger);">*</span></label>
                        <input type="text" name="unit" class="form-control" placeholder="e.g. Per 50kg Bag, Per Wheelie Bin" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Base Price (KES) <span style="color:var(--danger);">*</span></label>
                        <input type="number" step="0.01" name="base_price" class="form-control" placeholder="150.00" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">FontAwesome Icon Class</label>
                    <input type="text" name="icon" class="form-control" value="fa-trash-alt" placeholder="e.g. fa-recycle, fa-leaf, fa-laptop">
                </div>

                <div class="form-group">
                    <label class="form-label">Description & Permitted Waste Materials</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Provide clarity on what can be disposed in this category..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('addCategoryModal')">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Create Category</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Edit Category -->
<div class="modal-overlay" id="editCategoryModal">
    <div class="modal-box">
        <div class="modal-header">
            <h4 style="margin:0;"><i class="fa fa-edit" style="color:var(--primary);"></i> Edit Waste Category</h4>
            <button class="alert-close" onclick="closeModal('editCategoryModal')">&times;</button>
        </div>
        <form action="<?= $baseUrl ?>/admin/categories.php" method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="category_id" id="edit_cat_id">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Category Name <span style="color:var(--danger);">*</span></label>
                    <input type="text" name="name" id="edit_cat_name" class="form-control" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Billing Unit <span style="color:var(--danger);">*</span></label>
                        <input type="text" name="unit" id="edit_cat_unit" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Base Price (KES) <span style="color:var(--danger);">*</span></label>
                        <input type="number" step="0.01" name="base_price" id="edit_cat_price" class="form-control" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Icon Class</label>
                        <input type="text" name="icon" id="edit_cat_icon" class="form-control">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select name="status" id="edit_cat_status" class="form-control">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" id="edit_cat_desc" class="form-control" rows="3"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('editCategoryModal')">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(cat) {
    document.getElementById('edit_cat_id').value    = cat.id;
    document.getElementById('edit_cat_name').value  = cat.name;
    document.getElementById('edit_cat_unit').value  = cat.unit;
    document.getElementById('edit_cat_price').value = cat.base_price;
    document.getElementById('edit_cat_icon').value  = cat.icon || 'fa-trash-alt';
    document.getElementById('edit_cat_status').value = cat.status;
    document.getElementById('edit_cat_desc').value  = cat.description || '';
    openModal('editCategoryModal');
}
</script>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>