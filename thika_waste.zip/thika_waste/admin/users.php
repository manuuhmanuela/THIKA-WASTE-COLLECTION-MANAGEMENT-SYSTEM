<?php
// admin/users.php - Registered Residents Directory & Actions
require_once __DIR__ . '/includes/bootstrap.php';

// Handle User Status Toggle (Suspend / Activate)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
    $targetUserId = (int)($_POST['user_id'] ?? 0);
    $currentStatus = trim($_POST['current_status'] ?? 'active');
    $newStatus = ($currentStatus === 'active') ? 'suspended' : 'active';

    if ($targetUserId > 0) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ? AND role != 'admin'");
            $stmt->execute([$newStatus, $targetUserId]);
            setFlash('info', 'Resident account #' . $targetUserId . ' status updated to ' . $newStatus . '.');
        } catch (Exception $e) {
            setFlash('danger', 'Error updating user: ' . $e->getMessage());
        }
    }
    header('Location: ' . $baseUrl . '/admin/users.php');
    exit;
}

define('PAGE_TITLE', 'Registered Residents | Thika Waste Management');
require_once __DIR__ . '/includes/admin_header.php';

// Search and Zone Filter
$search = trim($_GET['search'] ?? '');
$zoneFilter = trim($_GET['zone'] ?? '');

$sql = "
    SELECT u.*, 
           COUNT(cr.id) AS total_requests,
           COALESCE(SUM(p.amount), 0) AS total_spent
    FROM users u
    LEFT JOIN collection_requests cr ON u.id = cr.user_id
    LEFT JOIN payments p ON cr.id = p.request_id AND p.payment_status = 'Completed'
    WHERE u.role = 'user'
";
$params = [];

if (!empty($zoneFilter)) {
    $sql .= " AND u.estate = ?";
    $params[] = $zoneFilter;
}
if (!empty($search)) {
    $sql .= " AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR u.address LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$sql .= " GROUP BY u.id ORDER BY u.id DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $residents = $stmt->fetchAll();
} catch (Exception $e) {
    die("Error fetching residents: " . $e->getMessage());
}
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
    <div>
        <h2><i class="fa fa-users" style="color:var(--primary); margin-right:8px;"></i> Registered Residents & Businesses</h2>
        <p style="margin:0;">Manage households, business accounts, and dispatch individual notifications across Thika.</p>
    </div>
    <a href="<?= $baseUrl ?>/admin/reminders.php" class="btn btn-primary">
        <i class="fa fa-paper-plane"></i> Send Targeted Notification
    </a>
</div>

<!-- Search & Filter -->
<div class="card" style="padding:1.25rem; margin-bottom:1.5rem;">
    <form action="<?= $baseUrl ?>/admin/users.php" method="GET" style="display:grid; grid-template-columns: 2fr 1.5fr 100px; gap:1rem; align-items:flex-end;">
        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Search Resident</label>
            <input type="text" name="search" class="form-control" placeholder="Name, Email, Phone, Address..." value="<?= htmlspecialchars($search) ?>">
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Filter by Thika Estate</label>
            <select name="zone" class="form-control">
                <option value="">All Thika Estates</option>
                <?php foreach (getThikaZones() as $zn): ?>
                    <option value="<?= htmlspecialchars($zn) ?>" <?= ($zoneFilter === $zn) ? 'selected' : '' ?>><?= htmlspecialchars($zn) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <button type="submit" class="btn btn-primary btn-block" style="padding:0.65rem 0.5rem;">
                <i class="fa fa-search"></i> Search
            </button>
        </div>
    </form>
</div>

<!-- Users Table -->
<div class="card">
    <div class="card-header">
        <h3 style="margin:0;">Resident Directory (<?= count($residents) ?> Accounts)</h3>
    </div>

    <?php if (empty($residents)): ?>
        <div style="text-align:center; padding:3rem 1rem; color:var(--slate-400);">
            <i class="fa fa-user-slash" style="font-size:2.5rem; margin-bottom:1rem;"></i>
            <h4>No Residents Found</h4>
            <p>Try resetting the search terms above.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Resident Name</th>
                        <th>Contact Info</th>
                        <th>Estate / Zone</th>
                        <th>Physical Address</th>
                        <th>Requests Placed</th>
                        <th>Total Paid</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($residents as $r): ?>
                        <tr>
                            <td><strong>#<?= $r['id'] ?></strong></td>
                            <td>
                                <strong><?= htmlspecialchars($r['name']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--slate-400);">Joined: <?= date('d M Y', strtotime($r['created_at'])) ?></div>
                            </td>
                            <td>
                                <div><i class="fa fa-envelope" style="color:var(--slate-400);"></i> <?= htmlspecialchars($r['email']) ?></div>
                                <div style="font-size:0.8rem; color:var(--primary); font-weight:600;"><i class="fa fa-phone"></i> <?= htmlspecialchars($r['phone']) ?></div>
                            </td>
                            <td>
                                <span class="badge badge-info"><i class="fa fa-map-pin"></i> <?= htmlspecialchars($r['estate']) ?></span>
                            </td>
                            <td>
                                <div style="max-width:200px; font-size:0.85rem; color:var(--slate-600);">
                                    <?= htmlspecialchars($r['address']) ?>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-primary"><?= $r['total_requests'] ?> Pickups</span>
                            </td>
                            <td>
                                <strong style="color:var(--primary);"><?= formatKES($r['total_spent']) ?></strong>
                            </td>
                            <td>
                                <?php if ($r['status'] === 'active'): ?>
                                    <span class="badge badge-success">Active</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Suspended</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div style="display:flex; gap:0.4rem;">
                                    <a href="<?= $baseUrl ?>/admin/reminders.php?user_id=<?= $r['id'] ?>" class="btn btn-sm btn-primary" title="Send Reminder specifically to <?= htmlspecialchars($r['name']) ?>">
                                        <i class="fa fa-bell"></i> Notify
                                    </a>

                                    <form action="<?= $baseUrl ?>/admin/users.php" method="POST" onsubmit="return confirm('Toggle status for <?= htmlspecialchars($r['name']) ?>?');" style="display:inline;">
                                        <input type="hidden" name="action" value="toggle_status">
                                        <input type="hidden" name="user_id" value="<?= $r['id'] ?>">
                                        <input type="hidden" name="current_status" value="<?= $r['status'] ?>">
                                        <button type="submit" class="btn btn-sm <?= ($r['status'] === 'active') ? 'btn-danger' : 'btn-success' ?>" title="<?= ($r['status'] === 'active') ? 'Suspend Account' : 'Activate Account' ?>">
                                            <i class="fa <?= ($r['status'] === 'active') ? 'fa-ban' : 'fa-check' ?>"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
