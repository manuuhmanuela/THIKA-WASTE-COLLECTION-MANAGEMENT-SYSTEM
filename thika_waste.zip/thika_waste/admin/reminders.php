<?php
// admin/reminders.php - Send Targeted Reminders to Specific Persons or Estates
require_once __DIR__ . '/includes/bootstrap.php';

$preselectedUserId = (int)($_GET['user_id'] ?? 0);
$refRequestId      = (int)($_GET['ref'] ?? 0);

$errors = [];

// Handle Send Reminder POST — runs before any output
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $targetMode   = trim($_POST['target_mode'] ?? 'person');
    $targetUserId = (int)($_POST['target_user_id'] ?? 0);
    $targetZone   = trim($_POST['target_zone'] ?? '');
    $title        = trim($_POST['title'] ?? '');
    $message      = trim($_POST['message'] ?? '');
    $type         = trim($_POST['type'] ?? 'reminder');

    if (empty($title))   $errors[] = 'Reminder title/subject is required.';
    if (empty($message)) $errors[] = 'Reminder message content cannot be blank.';

    if ($targetMode === 'person' && $targetUserId <= 0) {
        $errors[] = 'Please select a specific resident recipient.';
    } elseif ($targetMode === 'zone' && empty($targetZone)) {
        $errors[] = 'Please select a target Thika estate / zone.';
    }

    if (empty($errors)) {
        try {
            if ($targetMode === 'person') {
                $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)");
                $stmt->execute([$targetUserId, $title, $message, $type]);
                setFlash('success', 'Targeted reminder successfully delivered to selected resident.');
            } elseif ($targetMode === 'zone') {
                $zStmt = $pdo->prepare("SELECT id FROM users WHERE role = 'user' AND estate = ?");
                $zStmt->execute([$targetZone]);
                $zoneUsers = $zStmt->fetchAll();

                $ins = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)");
                $count = 0;
                foreach ($zoneUsers as $zu) {
                    $ins->execute([$zu['id'], $title, $message, $type]);
                    $count++;
                }
                setFlash('success', "Zone announcement dispatched to {$count} residents in {$targetZone}.");
            } else {
                $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (NULL, ?, ?, ?)");
                $stmt->execute([$title, $message, $type]);
                setFlash('success', 'Global announcement broadcast to all ThikaClean users.');
            }

            header('Location: ' . $baseUrl . '/admin/reminders.php');
            exit;
        } catch (Exception $e) {
            $errors[] = 'Failed to dispatch reminder: ' . $e->getMessage();
        }
    }
}

// NOW include the header (first output happens here)
define('PAGE_TITLE', 'Send Reminders & Alerts | Thika Waste Management');
require_once __DIR__ . '/includes/admin_header.php';

// Fetch all registered residents for dropdown
try {
    $stmt = $pdo->query("SELECT id, name, phone, estate, email FROM users WHERE role = 'user' AND status = 'active' ORDER BY name ASC");
    $residents = $stmt->fetchAll();
} catch (Exception $e) {
    $residents = [];
    $errors[] = 'Error fetching residents: ' . $e->getMessage();
}

// Fetch past dispatched reminders
try {
    $stmt = $pdo->query("
        SELECT n.*, u.name AS user_name, u.phone AS user_phone, u.estate AS user_estate
        FROM notifications n
        LEFT JOIN users u ON n.user_id = u.id
        ORDER BY n.id DESC LIMIT 20
    ");
    $recentReminders = $stmt->fetchAll();
} catch (Exception $e) {
    $recentReminders = [];
}
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
    <div>
        <h2><i class="fa fa-paper-plane" style="color:var(--primary); margin-right:8px;"></i> Targeted Reminders & Push Alerts</h2>
        <p style="margin:0;">Send customized pickup alerts, payment reminders, or route notifications directly to an individual or an entire Thika estate.</p>
    </div>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul style="margin:0; padding-left:1.25rem;">
            <?php foreach ($errors as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div style="display:grid; grid-template-columns: 1.2fr 1.8fr; gap:2rem;">
    <!-- Compose Form -->
    <div class="card" style="padding:2rem;">
        <div class="card-header" style="padding-top:0;">
            <h3><i class="fa fa-envelope-open" style="color:var(--primary); margin-right:8px;"></i> Compose Reminder</h3>
        </div>

        <form action="<?= $baseUrl ?>/admin/reminders.php" method="POST">
            <!-- Target Selector -->
            <div class="form-group">
                <label class="form-label">Send To <span style="color:var(--danger);">*</span></label>
                <div style="display:flex; gap:1.25rem; margin-bottom:0.75rem;">
                    <label style="display:flex; align-items:center; gap:0.4rem; cursor:pointer; font-size:0.9rem;">
                        <input type="radio" name="target_mode" value="person" id="mode_person" checked onchange="toggleRecipientMode()">
                        <strong>Specific Resident</strong>
                    </label>
                    <label style="display:flex; align-items:center; gap:0.4rem; cursor:pointer; font-size:0.9rem;">
                        <input type="radio" name="target_mode" value="zone" id="mode_zone" onchange="toggleRecipientMode()">
                        <strong>Thika Zone / Estate</strong>
                    </label>
                    <label style="display:flex; align-items:center; gap:0.4rem; cursor:pointer; font-size:0.9rem;">
                        <input type="radio" name="target_mode" value="all" id="mode_all" onchange="toggleRecipientMode()">
                        <strong>All Residents</strong>
                    </label>
                </div>
            </div>

            <!-- Specific Resident Dropdown -->
            <div class="form-group" id="group_person">
                <label class="form-label">Select Resident Person <span style="color:var(--danger);">*</span></label>
                <select name="target_user_id" id="target_user_id" class="form-control">
                    <option value="">-- Choose Resident --</option>
                    <?php foreach ($residents as $res): ?>
                        <option value="<?= $res['id'] ?>" <?= ($preselectedUserId === (int)$res['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($res['name']) ?> &mdash; <?= htmlspecialchars($res['phone']) ?> (<?= htmlspecialchars($res['estate']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Specific Zone Dropdown -->
            <div class="form-group" id="group_zone" style="display:none;">
                <label class="form-label">Select Thika Estate / Zone</label>
                <select name="target_zone" class="form-control">
                    <option value="">-- Choose Estate in Thika --</option>
                    <?php foreach (getThikaZones() as $zn): ?>
                        <option value="<?= htmlspecialchars($zn) ?>"><?= htmlspecialchars($zn) ?></option>
                    <?php endforeach; ?>
                </select>
                <small class="form-help">All registered households in this specific estate will receive this alert.</small>
            </div>

            <div class="form-group">
                <label class="form-label">Alert Category</label>
                <select name="type" class="form-control">
                    <option value="reminder">Collection Schedule Reminder</option>
                    <option value="payment">Pending Payment Reminder</option>
                    <option value="status_update">Truck Dispatched / Routing Alert</option>
                    <option value="general">Public Municipal Notice</option>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Reminder Title <span style="color:var(--danger);">*</span></label>
                <input type="text" name="title" class="form-control" placeholder="e.g. Garbage Truck Collection Tomorrow at 8:30 AM" value="<?= $refRequestId > 0 ? 'Update regarding Pickup Request #' . $refRequestId : '' ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Reminder Message Body <span style="color:var(--danger);">*</span></label>
                <textarea name="message" class="form-control" rows="5" placeholder="Dear resident, please remember to place your waste bags outside by 8:00 AM tomorrow as our Section 9 team will be conducting curbside collection..." required></textarea>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg">
                <i class="fa fa-paper-plane"></i> Send Alert Notification
            </button>
        </form>
    </div>

    <!-- Past Dispatched Reminders -->
    <div class="card" style="padding:2rem;">
        <div class="card-header" style="padding-top:0;">
            <h3><i class="fa fa-history" style="color:var(--primary); margin-right:8px;"></i> Recent Dispatched Alerts</h3>
        </div>

        <?php if (empty($recentReminders)): ?>
            <p style="text-align:center; color:var(--slate-400); padding:2rem 0;">No reminders logged yet.</p>
        <?php else: ?>
            <div style="display:flex; flex-direction:column; gap:1rem;">
                <?php foreach ($recentReminders as $rem): ?>
                    <div style="background:var(--slate-50); border:1px solid var(--slate-200); border-radius:var(--radius-md); padding:1rem;">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.4rem;">
                            <div>
                                <strong style="font-size:0.95rem; color:var(--dark);"><?= htmlspecialchars($rem['title']) ?></strong>
                                <div style="font-size:0.8rem; color:var(--primary); font-weight:600;">
                                    <?php if ($rem['user_id']): ?>
                                        <i class="fa fa-user"></i> To: <?= htmlspecialchars($rem['user_name']) ?> (<?= htmlspecialchars($rem['user_estate']) ?>)
                                    <?php else: ?>
                                        <i class="fa fa-broadcast-tower"></i> To: All Thika Residents (Broadcast)
                                    <?php endif; ?>
                                </div>
                            </div>
                            <span class="badge badge-secondary" style="font-size:0.7rem;">
                                <?= date('d M, H:i', strtotime($rem['created_at'])) ?>
                            </span>
                        </div>
                        <p style="font-size:0.85rem; color:var(--slate-600); margin:0 0 0.4rem 0;">
                            <?= htmlspecialchars($rem['message']) ?>
                        </p>
                        <span class="badge badge-warning" style="font-size:0.7rem;">
                            <i class="fa fa-bell"></i> <?= ucfirst($rem['type']) ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function toggleRecipientMode() {
    const isPerson = document.getElementById('mode_person').checked;
    const isZone   = document.getElementById('mode_zone').checked;

    document.getElementById('group_person').style.display = isPerson ? 'block' : 'none';
    document.getElementById('group_zone').style.display   = isZone   ? 'block' : 'none';
}
</script>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>