<?php
// admin/payments.php - Payments Ledger & Financial Verification
require_once __DIR__ . '/includes/bootstrap.php';

// Handle Payment Status Update (e.g. Confirming Cash or Manual M-Pesa)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'verify_payment') {
    $payId = (int)($_POST['payment_id'] ?? 0);
    $newStatus = trim($_POST['status'] ?? 'Completed');

    if ($payId > 0) {
        try {
            $stmt = $pdo->prepare("SELECT request_id, user_id, amount FROM payments WHERE id = ?");
            $stmt->execute([$payId]);
            $pay = $stmt->fetch();

            if ($pay) {
                // Update payment
                $pdo->prepare("UPDATE payments SET payment_status = ? WHERE id = ?")->execute([$newStatus, $payId]);

                // Update request payment status accordingly
                $reqPaymentStatus = ($newStatus === 'Completed') ? 'Paid' : 'Unpaid';
                $pdo->prepare("UPDATE collection_requests SET payment_status = ? WHERE id = ?")->execute([$reqPaymentStatus, $pay['request_id']]);

                // Notify user
                if ($newStatus === 'Completed') {
                    $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'payment')")->execute([
                        $pay['user_id'],
                        'Payment Verified by Admin',
                        'Your payment of ' . formatKES($pay['amount']) . ' for Request #' . $pay['request_id'] . ' has been verified by the finance desk.'
                    ]);
                }

                setFlash('success', 'Payment #' . $payId . ' status updated to ' . $newStatus . '.');
            }
        } catch (Exception $e) {
            setFlash('danger', 'Error updating payment: ' . $e->getMessage());
        }
    }
    header('Location: ' . $baseUrl . '/admin/payments.php');
    exit;
}

define('PAGE_TITLE', 'Payment Transactions | Thika Waste Management');
require_once __DIR__ . '/includes/admin_header.php';

// Filters
$filterMethod = $_GET['method'] ?? '';
$filterStatus = $_GET['status'] ?? '';
$search = trim($_GET['search'] ?? '');

$sql = "
    SELECT p.*, u.name AS user_name, u.phone AS user_phone, cr.estate_zone, wc.name AS category_name
    FROM payments p
    JOIN users u ON p.user_id = u.id
    JOIN collection_requests cr ON p.request_id = cr.id
    JOIN waste_categories wc ON cr.category_id = wc.id
    WHERE 1=1
";
$params = [];

if (!empty($filterMethod)) {
    $sql .= " AND p.payment_method = ?";
    $params[] = $filterMethod;
}
if (!empty($filterStatus)) {
    $sql .= " AND p.payment_status = ?";
    $params[] = $filterStatus;
}
if (!empty($search)) {
    $sql .= " AND (u.name LIKE ? OR p.transaction_reference LIKE ? OR u.phone LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$sql .= " ORDER BY p.id DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $payments = $stmt->fetchAll();

    // Calculate total verified revenue in current view
    $viewTotal = 0;
    foreach ($payments as $p) {
        if ($p['payment_status'] === 'Completed') {
            $viewTotal += (float)$p['amount'];
        }
    }
} catch (Exception $e) {
    die("Error loading payments: " . $e->getMessage());
}
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
    <div>
        <h2><i class="fa fa-money-bill-wave" style="color:var(--primary); margin-right:8px;"></i> Payment Transactions & Revenue</h2>
        <p style="margin:0;">Audit M-Pesa transactions, verify loader cash receipts, and monitor municipal collections.</p>
    </div>
    <div style="background:var(--white); border:1px solid var(--slate-200); border-radius:var(--radius-md); padding:0.6rem 1.25rem;">
        <span style="font-size:0.8rem; color:var(--slate-400); display:block;">Total Filtered Revenue</span>
        <strong style="font-size:1.4rem; color:var(--primary);"><?= formatKES($viewTotal) ?></strong>
    </div>
</div>

<!-- Search & Filter -->
<div class="card" style="padding:1.25rem; margin-bottom:1.5rem;">
    <form action="<?= $baseUrl ?>/admin/payments.php" method="GET" style="display:grid; grid-template-columns: 2fr 1fr 1fr 100px; gap:1rem; align-items:flex-end;">
        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Search Transaction</label>
            <input type="text" name="search" class="form-control" placeholder="Resident Name, Ref (e.g. QK...), Phone..." value="<?= htmlspecialchars($search) ?>">
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Method</label>
            <select name="method" class="form-control">
                <option value="">All Methods</option>
                <option value="M-Pesa" <?= ($filterMethod === 'M-Pesa') ? 'selected' : '' ?>>M-Pesa</option>
                <option value="Cash on Collection" <?= ($filterMethod === 'Cash on Collection') ? 'selected' : '' ?>>Cash on Collection</option>
                <option value="Bank Transfer" <?= ($filterMethod === 'Bank Transfer') ? 'selected' : '' ?>>Bank Transfer</option>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:0.8rem;">Payment Status</label>
            <select name="status" class="form-control">
                <option value="">All Statuses</option>
                <option value="Completed" <?= ($filterStatus === 'Completed') ? 'selected' : '' ?>>Completed</option>
                <option value="Pending" <?= ($filterStatus === 'Pending') ? 'selected' : '' ?>>Pending Verification</option>
                <option value="Failed" <?= ($filterStatus === 'Failed') ? 'selected' : '' ?>>Failed</option>
            </select>
        </div>

        <div>
            <button type="submit" class="btn btn-primary btn-block" style="padding:0.65rem 0.5rem;">
                <i class="fa fa-filter"></i> Filter
            </button>
        </div>
    </form>
</div>

<!-- Payments Table -->
<div class="card">
    <div class="card-header">
        <h3 style="margin:0;">Payment Records (<?= count($payments) ?> Entries)</h3>
    </div>

    <?php if (empty($payments)): ?>
        <div style="text-align:center; padding:3rem 1rem; color:var(--slate-400);">
            <i class="fa fa-receipt" style="font-size:2.5rem; margin-bottom:1rem;"></i>
            <h4>No Transactions Found</h4>
            <p>Try clearing your filters.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Receipt #</th>
                        <th>Req #</th>
                        <th>Resident Name</th>
                        <th>Estate</th>
                        <th>Category</th>
                        <th>Method</th>
                        <th>Reference Code</th>
                        <th>Amount</th>
                        <th>Paid At</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payments as $p): ?>
                        <tr>
                            <td><strong>REC-<?= str_pad($p['id'], 5, '0', STR_PAD_LEFT) ?></strong></td>
                            <td><a href="<?= $baseUrl ?>/admin/collections.php?search=<?= $p['request_id'] ?>">#<?= $p['request_id'] ?></a></td>
                            <td>
                                <strong><?= htmlspecialchars($p['user_name']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--slate-400);"><?= htmlspecialchars($p['user_phone']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($p['estate_zone']) ?></td>
                            <td><?= htmlspecialchars($p['category_name']) ?></td>
                            <td><i class="fa fa-mobile-alt" style="color:var(--primary);"></i> <?= htmlspecialchars($p['payment_method']) ?></td>
                            <td><code><?= htmlspecialchars($p['transaction_reference']) ?></code></td>
                            <td><strong style="color:var(--primary);"><?= formatKES($p['amount']) ?></strong></td>
                            <td><?= date('d M Y, H:i', strtotime($p['paid_at'])) ?></td>
                            <td><?= statusBadge($p['payment_status']) ?></td>
                            <td>
                                <?php if ($p['payment_status'] === 'Pending'): ?>
                                    <form action="<?= $baseUrl ?>/admin/payments.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="action" value="verify_payment">
                                        <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
                                        <input type="hidden" name="status" value="Completed">
                                        <button type="submit" class="btn btn-sm btn-success" title="Approve & Mark Paid">
                                            <i class="fa fa-check"></i> Approve
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span style="font-size:0.8rem; color:var(--slate-400);"><i class="fa fa-check-double" style="color:var(--success);"></i> Verified</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
