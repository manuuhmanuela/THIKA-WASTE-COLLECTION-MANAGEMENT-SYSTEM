<?php
// admin/login.php - Direct shortcut to system login
require_once __DIR__ . '/../config/auth.php';

if (isAdmin()) {
    header('Location: ' . getBaseUrl() . '/admin/index.php');
    exit;
}

// Redirect to main login with admin note
header('Location: ' . getBaseUrl() . '/login.php');
exit;
