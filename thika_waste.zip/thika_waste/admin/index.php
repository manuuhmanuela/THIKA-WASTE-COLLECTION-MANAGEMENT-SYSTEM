<?php
// admin/index.php - Executive Operations Dashboard
define('PAGE_TITLE', 'Admin Dashboard | Thika Waste Management');
require_once __DIR__ . '/includes/admin_header.php';

// Fetch overview metrics
try {
    // Total revenue
    $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE payment_status = 'Completed'");
    $totalRevenue = (float)$stmt->fetchColumn();

    // Total collections
    $totalCollections = (int)$pdo->query("SELECT COUNT(*) FROM collection_requests")->fetchColumn();

    // Pending collections
    $pendingCollections = (int)$pdo->query("SELECT COUNT(*) FROM collection_requests WHERE status = 'Pending'")->fetchColumn();

    // Completed collections
    $completedCollections = (int)$pdo->query("SELECT COUNT(*) FROM collection_requests WHERE status = 'Completed'")->fetchColumn();

    // Registered residents
    $totalResidents = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();

    // Active categories
    $totalCategories = (int)$pdo->query("SELECT COUNT(*) FROM waste_categories WHERE status = 'active'")->fetchColumn();

    // Urgent Pending Requests (needing approval/scheduling)
    $stmt = $pdo->query("
        SELECT cr.*, u.name AS user_name, u.phone AS user_phone, wc.name AS category_name, wc.unit AS category_unit
        FROM collection_requests cr
        JOIN users u ON cr.user_id = u.id
        JOIN waste_categories wc ON cr.category_id = wc.id
        WHERE cr.status = 'Pending'
        ORDER BY cr.id ASC LIMIT 5
    ");
    $urgentRequests = $stmt->fetchAll();

    // Recent Payments
    $stmt = $pdo->query("
        SELECT p.*, u.name AS user_name, cr.estate_zone, wc.name AS category_name
        FROM payments p
        JOIN users u ON p.user_id = u.id
        JOIN collection_requests cr ON p.request_id = cr.id
        JOIN waste_categories wc ON cr.category_id = wc.id
        ORDER BY p.id DESC LIMIT 5
    ");
    $recentPayments = $stmt->fetchAll();

    // Estate Breakdown
    $stmt = $pdo->query("
        SELECT estate_zone, COUNT(*) AS req_count, COALESCE(SUM(total_amount), 0) AS zone_total
        FROM collection_requests
        GROUP BY estate_zone
        ORDER BY req_count DESC LIMIT 6
    ");
    $zoneBreakdown = $stmt->fetchAll();

} catch (Exception $e) {
    die("Error loading admin dashboard: " . $e->getMessage());
}
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2rem; flex-wrap:wrap; gap:1rem;">
    <div>
        <h2 style="margin:0;">Operations & Municipal Command</h2>
        <p style="margin:0; font-size:0.95rem;">Real-time overview of solid waste pickups across Thika Municipality.</p>
    </div>
    <div style="display:flex; gap:0.75rem;">
        <a href="<?= $baseUrl ?>/admin/reminders.php" class="btn btn-secondary">
            <i class="fa fa-bell"></i> Send Reminder to Resident
        </a>
        <a href="<?= $baseUrl ?>/admin/reports.php" class="btn btn-primary">
            <i class="fa fa-file-excel"></i> Generate Report
        </a>
    </div>
</div>

<!-- KPI Metric Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon stat-icon-primary"><i class="fa fa-money-bill-wave"></i></div>
        <div>
            <div class="stat-number"><?= formatKES($totalRevenue) ?></div>
            <div class="stat-label">Total Revenue Collected</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-warning"><i class="fa fa-hourglass-start"></i></div>
        <div>
            <div class="stat-number"><?= number_format($pendingCollections) ?></div>
            <div class="stat-label">Pending Pickups (Needs Action)</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-success"><i class="fa fa-truck-moving"></i></div>
        <div>
            <div class="stat-number"><?= number_format($completedCollections) ?></div>
            <div class="stat-label">Completed Collections</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-info"><i class="fa fa-users"></i></div>
        <div>
            <div class="stat-number"><?= number_format($totalResidents) ?></div>
            <div class="stat-label">Registered Residents</div>
        </div>
    </div>
</div>

<!-- Urgent Actions Table -->
<div class="card" style="margin-bottom:2rem;">
    <div class="card-header">
        <div style="display:flex; align-items:center; gap:0.6rem;">
            <span class="badge badge-warning" style="font-size:0.85rem;"><i class="fa fa-exclamation-triangle"></i> Action Required</span>
            <h3 style="margin:0;">Pending Collection Bookings</h3>
        </div>
        <a href="<?= $baseUrl ?>/admin/collections.php?status=Pending" class="btn btn-sm btn-outline-primary">View All Collections</a>
    </div>

    <?php if (empty($urgentRequests)): ?>
        <div style="text-align:center; padding:2rem 0; color:var(--slate-400);">
            <i class="fa fa-check-circle" style="font-size:2rem; color:var(--success); margin-bottom:0.5rem;"></i>
            <p style="margin:0;">No pending requests! All scheduled pickups have been approved or dispatched.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Req #</th>
                        <th>Resident</th>
                        <th>Category</th>
                        <th>Thika Zone & Address</th>
                        <th>Pickup Date & Slot</th>
                        <th>Amount</th>
                        <th>Payment</th>
                        <th>Quick Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($urgentRequests as $req): ?>
                        <tr>
                            <td><strong>#<?= $req['id'] ?></strong></td>
                            <td>
                                <strong><?= htmlspecialchars($req['user_name']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--slate-400);"><i class="fa fa-phone"></i> <?= htmlspecialchars($req['user_phone']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($req['category_name']) ?> (<?= $req['quantity'] ?> <?= htmlspecialchars($req['category_unit']) ?>)</td>
                            <td>
                                <strong><?= htmlspecialchars($req['estate_zone']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--slate-400);"><?= htmlspecialchars(substr($req['pickup_address'], 0, 35)) ?>...</div>
                            </td>
                            <td>
                                <div><i class="fa fa-calendar-day"></i> <?= date('d M Y', strtotime($req['pickup_date'])) ?></div>
                                <small style="color:var(--slate-400);"><?= htmlspecialchars($req['pickup_time_slot']) ?></small>
                            </td>
                            <td><strong><?= formatKES($req['total_amount']) ?></strong></td>
                            <td><?= statusBadge($req['payment_status']) ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary" onclick="openStatusModal('<?= $req['id'] ?>', '<?= $req['status'] ?>', '<?= htmlspecialchars(addslashes($req['notes'] ?? '')) ?>')">
                                    <i class="fa fa-edit"></i> Change Status
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Split Bottom Row: Recent Payments & Thika Estate Stats -->
<div style="display:grid; grid-template-columns: 1.3fr 1fr; gap:2rem;">
    <!-- Recent Revenue Logs -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fa fa-credit-card" style="color:var(--primary); margin-right:8px;"></i> Recent Payments</h3>
            <a href="<?= $baseUrl ?>/admin/payments.php" class="btn btn-sm btn-secondary">All Payments</a>
        </div>

        <?php if (empty($recentPayments)): ?>
            <p style="text-align:center; color:var(--slate-400); padding:2rem 0;">No payments received yet.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Ref</th>
                            <th>Resident</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentPayments as $p): ?>
                            <tr>
                                <td><code><?= htmlspecialchars($p['transaction_reference']) ?></code></td>
                                <td><?= htmlspecialchars($p['user_name']) ?></td>
                                <td><strong><?= formatKES($p['amount']) ?></strong></td>
                                <td><?= date('d M, H:i', strtotime($p['paid_at'])) ?></td>
                                <td><?= statusBadge($p['payment_status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- Estate Performance Distribution -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fa fa-map-marked-alt" style="color:var(--primary); margin-right:8px;"></i> Top Thika Zones</h3>
            <span class="badge badge-info"><?= count($zoneBreakdown) ?> Active Zones</span>
        </div>

        <?php if (empty($zoneBreakdown)): ?>
            <p style="text-align:center; color:var(--slate-400); padding:2rem 0;">No zone data available.</p>
        <?php else: ?>
            <div style="display:flex; flex-direction:column; gap:1rem;">
                <?php foreach ($zoneBreakdown as $zb): ?>
                    <div style="background:var(--slate-50); border:1px solid var(--slate-200); border-radius:var(--radius-md); padding:0.875rem; display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <strong style="font-size:0.95rem; color:var(--dark);"><i class="fa fa-map-pin" style="color:var(--primary); margin-right:6px;"></i> <?= htmlspecialchars($zb['estate_zone']) ?></strong>
                            <div style="font-size:0.75rem; color:var(--slate-400);"><?= $zb['req_count'] ?> Total Pickups Recorded</div>
                        </div>
                        <div style="text-align:right;">
                            <strong style="color:var(--primary); font-size:1rem;"><?= formatKES($zb['zone_total']) ?></strong>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal for Changing Status -->
<div class="modal-overlay" id="statusChangeModal">
    <div class="modal-box">
        <div class="modal-header">
            <h4 style="margin:0;"><i class="fa fa-sliders-h" style="color:var(--primary);"></i> Update Collection Request Status</h4>
            <button class="alert-close" onclick="closeModal('statusChangeModal')">&times;</button>
        </div>
        <form action="<?= $baseUrl ?>/admin/collections.php" method="POST">
            <input type="hidden" name="action" value="update_status">
            <input type="hidden" name="request_id" id="modal_request_id" value="">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">New Status</label>
                    <select name="status" id="modal_status_select" class="form-control" required>
                        <option value="Pending">Pending (Awaiting Confirmation)</option>
                        <option value="Approved">Approved (Scheduled for Pickup)</option>
                        <option value="In Progress">In Progress (Driver Dispatched)</option>
                        <option value="Completed">Completed (Waste Collected & Cleared)</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Operational Note / Message to Resident</label>
                    <textarea name="status_note" id="modal_notes" class="form-control" rows="3" placeholder="e.g. Truck registration KDA 123X dispatched. Driver Samuel en route to Section 9."></textarea>
                    <small class="form-help">This note will be automatically sent as a notification to the resident.</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('statusChangeModal')">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Save & Notify Resident</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
