<?php
// admin/messages.php - Resident Inquiries & Support Messaging
require_once __DIR__ . '/includes/bootstrap.php';

// Handle Reply to Resident
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reply') {
    $targetUserId = (int)($_POST['user_id'] ?? 0);
    $originalMsgId = (int)($_POST['original_msg_id'] ?? 0);
    $replySubject = trim($_POST['subject'] ?? 'RE: Support Inquiry');
    $replyContent = trim($_POST['reply_content'] ?? '');

    if ($targetUserId > 0 && !empty($replyContent)) {
        try {
            // Insert admin reply
            $stmt = $pdo->prepare("INSERT INTO messages (user_id, sender_type, subject, message, is_read) VALUES (?, 'admin', ?, ?, 0)");
            $stmt->execute([$targetUserId, $replySubject, $replyContent]);

            // Mark original message as read
            if ($originalMsgId > 0) {
                $pdo->prepare("UPDATE messages SET is_read = 1 WHERE id = ?")->execute([$originalMsgId]);
            }

            // Create notification for resident
            $notif = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'general')");
            $notif->execute([
                $targetUserId,
                'New Reply from Thika Waste Support',
                'Our dispatch team has replied to your message: "' . htmlspecialchars(substr($replyContent, 0, 70)) . '..."'
            ]);

            setFlash('success', 'Reply dispatched to resident successfully.');
        } catch (Exception $e) {
            setFlash('danger', 'Error sending reply: ' . $e->getMessage());
        }
    }
    header('Location: ' . $baseUrl . '/admin/messages.php');
    exit;
}

// Handle Contact Form Inquiry Status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mark_contact_responded') {
    $contactId = (int)($_POST['contact_id'] ?? 0);
    if ($contactId > 0) {
        $pdo->prepare("UPDATE contact_inquiries SET status = 'Responded' WHERE id = ?")->execute([$contactId]);
        setFlash('info', 'Contact inquiry #' . $contactId . ' marked as Responded.');
    }
    header('Location: ' . $baseUrl . '/admin/messages.php');
    exit;
}

define('PAGE_TITLE', 'Support Messages & Inquiries | Thika Waste Management');
require_once __DIR__ . '/includes/admin_header.php';

// Fetch resident messages
try {
    $stmt = $pdo->query("
        SELECT m.*, u.name AS user_name, u.phone AS user_phone, u.email AS user_email, u.estate AS user_estate
        FROM messages m
        JOIN users u ON m.user_id = u.id
        ORDER BY m.id DESC
    ");
    $residentMessages = $stmt->fetchAll();

    // Fetch public contact inquiries
    $stmt = $pdo->query("SELECT * FROM contact_inquiries ORDER BY id DESC");
    $contactInquiries = $stmt->fetchAll();
} catch (Exception $e) {
    die("Error fetching messages: " . $e->getMessage());
}
?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
    <div>
        <h2><i class="fa fa-envelope-open-text" style="color:var(--primary); margin-right:8px;"></i> Support Inquiries & Messages</h2>
        <p style="margin:0;">Reply to resident queries and review inquiries submitted via the public contact portal.</p>
    </div>
</div>

<div style="display:grid; grid-template-columns: 1.5fr 1fr; gap:2rem;">
    <!-- Resident Portal Messages -->
    <div class="card" style="padding:1.5rem;">
        <div class="card-header" style="padding-top:0;">
            <h3 style="margin:0;"><i class="fa fa-comments" style="color:var(--primary); margin-right:8px;"></i> Registered Resident Conversations</h3>
        </div>

        <?php if (empty($residentMessages)): ?>
            <p style="text-align:center; color:var(--slate-400); padding:2rem 0;">No messages received from residents yet.</p>
        <?php else: ?>
            <div style="display:flex; flex-direction:column; gap:1.25rem;">
                <?php foreach ($residentMessages as $m): ?>
                    <?php $isAdmin = ($m['sender_type'] === 'admin'); ?>
                    <div style="background:<?= $isAdmin ? '#f0fdf4' : '#f8fafc' ?>; border:1px solid <?= $isAdmin ? '#bbf7d0' : '#e2e8f0' ?>; border-left:4px solid <?= $isAdmin ? 'var(--primary)' : 'var(--secondary)' ?>; border-radius:var(--radius-md); padding:1.25rem;">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.5rem;">
                            <div>
                                <span class="badge <?= $isAdmin ? 'badge-success' : 'badge-primary' ?>" style="font-size:0.75rem; margin-bottom:0.35rem;">
                                    <i class="fa <?= $isAdmin ? 'fa-shield-alt' : 'fa-user' ?>"></i> <?= $isAdmin ? 'Sent by Operations Admin' : 'From Resident: ' . htmlspecialchars($m['user_name']) ?>
                                </span>
                                <h4 style="margin:0; font-size:1.05rem;"><?= htmlspecialchars($m['subject']) ?></h4>
                                <?php if (!$isAdmin): ?>
                                    <div style="font-size:0.75rem; color:var(--slate-400); margin-top:2px;">
                                        <i class="fa fa-map-marker-alt"></i> <?= htmlspecialchars($m['user_estate']) ?> &bull; <i class="fa fa-phone"></i> <?= htmlspecialchars($m['user_phone']) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div style="text-align:right;">
                                <small style="color:var(--slate-400); font-size:0.75rem;"><?= date('d M Y, H:i', strtotime($m['created_at'])) ?></small>
                                <?php if (!$isAdmin): ?>
                                    <div style="margin-top:0.4rem;">
                                        <button class="btn btn-sm btn-primary" onclick="openReplyModal('<?= $m['user_id'] ?>', '<?= $m['id'] ?>', '<?= htmlspecialchars(addslashes($m['subject'])) ?>', '<?= htmlspecialchars(addslashes($m['user_name'])) ?>')">
                                            <i class="fa fa-reply"></i> Reply
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div style="font-size:0.9rem; color:var(--slate-600); line-height:1.6; white-space:pre-line; margin-top:0.5rem;">
                            <?= htmlspecialchars($m['message']) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Public Contact Form Inquiries -->
    <div class="card" style="padding:1.5rem;">
        <div class="card-header" style="padding-top:0;">
            <h3 style="margin:0;"><i class="fa fa-inbox" style="color:var(--info); margin-right:8px;"></i> Public Contact Inquiries</h3>
        </div>

        <?php if (empty($contactInquiries)): ?>
            <p style="text-align:center; color:var(--slate-400); padding:2rem 0;">No website contact messages.</p>
        <?php else: ?>
            <div style="display:flex; flex-direction:column; gap:1rem;">
                <?php foreach ($contactInquiries as $ci): ?>
                    <div style="background:var(--slate-50); border:1px solid var(--slate-200); border-radius:var(--radius-md); padding:1rem;">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.4rem;">
                            <div>
                                <strong style="font-size:0.95rem;"><?= htmlspecialchars($ci['name']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--slate-400);">
                                    <i class="fa fa-envelope"></i> <?= htmlspecialchars($ci['email']) ?> &bull; <i class="fa fa-phone"></i> <?= htmlspecialchars($ci['phone']) ?>
                                </div>
                            </div>
                            <span class="badge <?= ($ci['status'] === 'New') ? 'badge-danger' : 'badge-success' ?>" style="font-size:0.7rem;">
                                <?= htmlspecialchars($ci['status']) ?>
                            </span>
                        </div>
                        <strong style="font-size:0.9rem; color:var(--primary); display:block; margin:0.35rem 0;"><?= htmlspecialchars($ci['subject']) ?></strong>
                        <p style="font-size:0.85rem; color:var(--slate-600); margin:0 0 0.5rem 0;">
                            <?= htmlspecialchars($ci['message']) ?>
                        </p>
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <small style="color:var(--slate-400); font-size:0.75rem;"><?= date('d M, H:i', strtotime($ci['created_at'])) ?></small>
                            <?php if ($ci['status'] === 'New'): ?>
                                <form action="<?= $baseUrl ?>/admin/messages.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="mark_contact_responded">
                                    <input type="hidden" name="contact_id" value="<?= $ci['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-secondary">
                                        <i class="fa fa-check"></i> Mark Responded
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal: Reply to Resident -->
<div class="modal-overlay" id="replyModal">
    <div class="modal-box">
        <div class="modal-header">
            <h4 style="margin:0;"><i class="fa fa-reply" style="color:var(--primary);"></i> Reply to Resident Message</h4>
            <button class="alert-close" onclick="closeModal('replyModal')">&times;</button>
        </div>
        <form action="<?= $baseUrl ?>/admin/messages.php" method="POST">
            <input type="hidden" name="action" value="reply">
            <input type="hidden" name="user_id" id="reply_user_id">
            <input type="hidden" name="original_msg_id" id="reply_orig_id">
            <div class="modal-body">
                <div style="background:var(--slate-100); padding:0.75rem 1rem; border-radius:var(--radius-md); margin-bottom:1rem; font-size:0.875rem;">
                    Replying to: <strong id="reply_user_display">-</strong>
                </div>

                <div class="form-group">
                    <label class="form-label">Subject</label>
                    <input type="text" name="subject" id="reply_subject" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Your Response Content <span style="color:var(--danger);">*</span></label>
                    <textarea name="reply_content" class="form-control" rows="5" placeholder="Type your message to the resident here..." required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('replyModal')">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Send Reply</button>
            </div>
        </form>
    </div>
</div>

<script>
function openReplyModal(userId, origId, subject, userName) {
    document.getElementById('reply_user_id').value = userId;
    document.getElementById('reply_orig_id').value = origId;
    document.getElementById('reply_subject').value = 'RE: ' + subject.replace(/^RE:\s*/i, '');
    document.getElementById('reply_user_display').textContent = userName;
    openModal('replyModal');
}
</script>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
