/**
 * Thika Waste Management System - Main JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {
  // 1. Mobile Menu Toggle
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener('click', function () {
      navLinks.classList.toggle('active');
    });
  }

  // 2. Auto-dismiss alerts after 5 seconds
  const alerts = document.querySelectorAll('.alert');
  alerts.forEach(function (alert) {
    const closeBtn = alert.querySelector('.alert-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', function () {
        alert.remove();
      });
    }
    setTimeout(function () {
      if (alert && alert.parentElement) {
        alert.style.transition = 'opacity 0.5s ease';
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 500);
      }
    }, 5000);
  });

  // 3. Dynamic Garbage Collection Price Calculation
  const categorySelect = document.getElementById('category_id');
  const quantityInput = document.getElementById('quantity');
  const unitPriceDisplay = document.getElementById('display_unit_price');
  const totalAmountDisplay = document.getElementById('display_total_amount');
  const totalAmountInput = document.getElementById('total_amount_input');
  const unitNameDisplay = document.getElementById('display_unit_name');
  const categoryDescDisplay = document.getElementById('display_category_desc');

  function calculateGarbagePrice() {
    if (!categorySelect || !quantityInput) return;

    const selectedOption = categorySelect.options[categorySelect.selectedIndex];
    if (!selectedOption || !selectedOption.value) {
      if (unitPriceDisplay) unitPriceDisplay.textContent = 'KES 0.00';
      if (totalAmountDisplay) totalAmountDisplay.textContent = 'KES 0.00';
      if (totalAmountInput) totalAmountInput.value = '0.00';
      if (categoryDescDisplay) categoryDescDisplay.textContent = 'Please choose a category.';
      return;
    }

    const price = parseFloat(selectedOption.getAttribute('data-price')) || 0;
    const unit = selectedOption.getAttribute('data-unit') || 'unit';
    const desc = selectedOption.getAttribute('data-desc') || '';
    const quantity = parseInt(quantityInput.value, 10) || 1;

    const total = price * quantity;

    if (unitPriceDisplay) {
      unitPriceDisplay.textContent = 'KES ' + price.toLocaleString('en-KE', { minimumFractionDigits: 2 });
    }
    if (unitNameDisplay) {
      unitNameDisplay.textContent = unit;
    }
    if (totalAmountDisplay) {
      totalAmountDisplay.textContent = 'KES ' + total.toLocaleString('en-KE', { minimumFractionDigits: 2 });
    }
    if (totalAmountInput) {
      totalAmountInput.value = total.toFixed(2);
    }
    if (categoryDescDisplay) {
      categoryDescDisplay.textContent = desc;
    }
  }

  if (categorySelect && quantityInput) {
    categorySelect.addEventListener('change', calculateGarbagePrice);
    quantityInput.addEventListener('input', calculateGarbagePrice);
    // Initial run on page load
    calculateGarbagePrice();
  }

  // 4. Generic Modal Handling
  window.openModal = function (modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
    }
  };

  window.closeModal = function (modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
    }
  };

  // Close modal when clicking on overlay background
  document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) {
        overlay.classList.remove('active');
      }
    });
  });

  // 5. Admin Status Change Modal Trigger
  window.openStatusModal = function (requestId, currentStatus, currentNotes) {
    const reqIdInput = document.getElementById('modal_request_id');
    const statusSelect = document.getElementById('modal_status_select');
    const notesInput = document.getElementById('modal_notes');

    if (reqIdInput) reqIdInput.value = requestId;
    if (statusSelect) statusSelect.value = currentStatus;
    if (notesInput) notesInput.value = currentNotes || '';

    openModal('statusChangeModal');
  };

  // 6. M-Pesa Checkout Simulator
  const stkSimulateBtn = document.getElementById('btn_simulate_stk');
  const stkStatusBox = document.getElementById('stk_status_box');
  if (stkSimulateBtn && stkStatusBox) {
    stkSimulateBtn.addEventListener('click', function () {
      const phone = document.getElementById('mpesa_phone').value;
      if (!phone) {
        alert('Please enter your M-Pesa phone number');
        return;
      }
      stkSimulateBtn.disabled = true;
      stkStatusBox.style.display = 'block';
      stkStatusBox.innerHTML = `
        <div style="text-align:center; padding: 1rem;">
          <i class="fa fa-spinner fa-spin" style="font-size:2rem; color:#059669; margin-bottom:0.75rem;"></i>
          <p><strong>Sending STK Push prompt to ${phone}...</strong></p>
          <p style="font-size:0.85rem; color:#64748b;">Please check your phone and enter your M-Pesa PIN.</p>
        </div>
      `;

      setTimeout(function () {
        // Generate pseudo reference
        const randomRef = 'QK' + Math.floor(10000000 + Math.random() * 90000000);
        stkStatusBox.innerHTML = `
          <div style="background:#d1fae5; color:#065f46; padding:1rem; border-radius:8px; text-align:center;">
            <i class="fa fa-check-circle" style="font-size:2rem; margin-bottom:0.5rem;"></i>
            <p><strong>Payment Received Successfully!</strong></p>
            <p>Reference: <strong>${randomRef}</strong></p>
            <input type="hidden" name="transaction_ref" value="${randomRef}">
          </div>
        `;
        const submitPayBtn = document.getElementById('btn_complete_payment');
        const refInput = document.getElementById('transaction_reference');
        if (refInput) refInput.value = randomRef;
        if (submitPayBtn) {
          submitPayBtn.disabled = false;
          submitPayBtn.click();
        }
      }, 3500);
    });
  }
});
