<?php
// config/auth.php - Session management, authentication, and helper functions

// Enable output buffering to ensure header() redirects never encounter 'headers already sent'
if (ob_get_level() === 0) {
    ob_start();
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

// Base URL helper - explicitly anchored to /thika_waste for localhost/thika_waste
define('BASE_PATH', '/thika_waste');

function getBaseUrl() {
    return '/thika_waste';
}

// Global base URL variable available across all pages
$baseUrl = getBaseUrl();


// Thika Estate Zones
function getThikaZones() {
    return [
        'Thika Town',
        'Section 9',
        'Makongeni',
        'Ngoingwa',
        'Landless',
        'Chania',
        'Kisii Estate',
        'Kiganjo',
        'Pilot',
        'BAT Area',
        'Broadways Area',
        'Del Monte Area',
        'Witeithie Outskirts'
    ];
}

// Authentication checks
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function currentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'] ?? 'User',
        'email' => $_SESSION['user_email'] ?? '',
        'phone' => $_SESSION['user_phone'] ?? '',
        'role' => $_SESSION['user_role'] ?? 'user',
        'estate' => $_SESSION['user_estate'] ?? 'Thika',
    ];
}

function requireLogin($redirect = '/login.php') {
    if (!isLoggedIn()) {
        setFlash('warning', 'Please login to access this page.');
        header('Location: ' . getBaseUrl() . '/' . ltrim($redirect, '/'));
        exit;
    }
}

function requireAdmin($redirect = '/login.php') {
    if (!isAdmin()) {
        setFlash('danger', 'Access denied. Administrator privileges required.');
        header('Location: ' . getBaseUrl() . '/' . ltrim($redirect, '/'));
        exit;
    }
}

// Flash Message Helpers
function setFlash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// UI Helpers
function formatKES($amount) {
    return 'KES ' . number_format((float)$amount, 2);
}

function statusBadge($status) {
    $status = trim($status);
    switch ($status) {
        case 'Pending':
            return '<span class="badge badge-warning"><i class="fa fa-clock"></i> Pending</span>';
        case 'Approved':
            return '<span class="badge badge-info"><i class="fa fa-check-circle"></i> Approved</span>';
        case 'In Progress':
            return '<span class="badge badge-primary"><i class="fa fa-truck"></i> In Progress</span>';
        case 'Completed':
            return '<span class="badge badge-success"><i class="fa fa-check-double"></i> Completed</span>';
        case 'Cancelled':
            return '<span class="badge badge-danger"><i class="fa fa-times-circle"></i> Cancelled</span>';
        case 'Paid':
            return '<span class="badge badge-success"><i class="fa fa-check"></i> Paid</span>';
        case 'Unpaid':
            return '<span class="badge badge-danger"><i class="fa fa-exclamation-circle"></i> Unpaid</span>';
        case 'Pending Verification':
            return '<span class="badge badge-warning"><i class="fa fa-hourglass-half"></i> Verifying</span>';
        default:
            return '<span class="badge badge-secondary">' . htmlspecialchars($status) . '</span>';
    }
}

// User unread notifications counter
function getUnreadNotificationsCount($pdo, $userId = null) {
    try {
        if ($userId) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0");
            $stmt->execute([$userId]);
        } else {
            $stmt = $pdo->query("SELECT COUNT(*) FROM notifications WHERE is_read = 0");
        }
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

// User unread messages counter
function getUnreadMessagesCount($pdo, $userId) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE user_id = ? AND sender_type = 'admin' AND is_read = 0");
        $stmt->execute([$userId]);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

// Admin pending collections counter
function getPendingCollectionsCount($pdo) {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM collection_requests WHERE status = 'Pending'");
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}
