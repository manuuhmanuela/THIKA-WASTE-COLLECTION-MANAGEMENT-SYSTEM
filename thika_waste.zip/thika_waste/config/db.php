<?php
// config/db.php - Database connection with automatic bootstrap for XAMPP

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'thika_waste');

function getDBConnection() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    try {
        // Try connecting to existing database
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        // If database does not exist, try creating it and importing schema
        if ($e->getCode() == 1049) { // Unknown database error
            try {
                $serverDsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";charset=utf8mb4";
                $serverPdo = new PDO($serverDsn, DB_USER, DB_PASS);
                $serverPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                
                $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
                
                // Read and execute database.sql
                $sqlFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'database.sql';
                if (file_exists($sqlFile)) {
                    $sqlContent = file_get_contents($sqlFile);
                    $pdo->exec($sqlContent);
                }
                return $pdo;
            } catch (Exception $initEx) {
                die("<div style='font-family:sans-serif;max-width:600px;margin:50px auto;padding:20px;border:1px solid #f87171;background:#fef2f2;border-radius:8px;'>
                    <h3 style='color:#dc2626;'>Database Initialization Error</h3>
                    <p>" . htmlspecialchars($initEx->getMessage()) . "</p>
                    <p>Please make sure MySQL is running in your XAMPP Control Panel.</p>
                </div>");
            }
        }

        die("<div style='font-family:sans-serif;max-width:600px;margin:50px auto;padding:20px;border:1px solid #f87171;background:#fef2f2;border-radius:8px;'>
            <h3 style='color:#dc2626;'>Database Connection Error</h3>
            <p>" . htmlspecialchars($e->getMessage()) . "</p>
            <p>Ensure MySQL is started in XAMPP. Default connection: <strong>localhost:3306</strong>, User: <strong>root</strong>, Password: (empty).</p>
        </div>");
    }
}

// Global DB instance
$pdo = getDBConnection();
